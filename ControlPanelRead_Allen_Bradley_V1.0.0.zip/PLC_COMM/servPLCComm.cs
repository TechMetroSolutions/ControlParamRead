﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Timers;
using System.Windows.Forms;

namespace CheckAppRunning
{
    public partial class Service1 : ServiceBase
    {
        public Service1()
        {
            InitializeComponent();
        }
        protected override void OnStart(string[] args)
        {
            try
            {
              // Debugger.Launch();
             
                fnGetDeviceDetails();
                for (int i = 0; i < Program.objclsComm.strlstDevIPAddress.Count; i++)
                {
                    iIPIndex = i;
                    Thread thr = new Thread(new ThreadStart(fnCreateThreads));
                    thr.Start();
                }
            }
            catch (Exception ex)
            {
                string s = ex.Message;
            }
        }
     
        public void fnCheckQueue()
        {
            try
            {
                for (int i = 0; i < Program.objclsComm.strlstUrlToExecute.Count; i++)
                {
                    Program.objAdvanceHMI.strURLToExecute = Program.objclsComm.strlstUrlToExecute[i];
                    Program.objAdvanceHMI.data = Program.objclsComm.bytlstarray[i];
                    Program.objAdvanceHMI.fnSendDatawithURL();
                }
                Program.objclsComm.strlstUrlToExecute.Clear();
                Program.objclsComm.bytlstarray.Clear();
            }
            catch(Exception ec)
            {
                Logger.Error(ec.Message);
            }
        }

        protected override void OnStop()
        {

        }

        private void fnGetDeviceDetails()
        {
            Logger.Info("Entering into fnReadCreateDevice()");
            try
            {
                clsIniFiles ini = new clsIniFiles(Application.StartupPath + "\\CreateDeviceConfig.ini");
                clsIniFiles inii = new clsIniFiles(Application.StartupPath + "\\CommanSettingConfig.ini");
                int int_CreateDeviceSaveIndex = Convert.ToInt32(ini.IniReadValue("Device Count", "Total Count"));
                Program.objclsComm.strCustomerName = inii.IniReadValue("CommanSetting", "Customer Name");
                Program.objclsComm.iUpdateFreq = Convert.ToInt32(inii.IniReadValue("CommanSetting", "Read Frequency"));
                Program.objclsComm.strBasicURL = inii.IniReadValue("CommanSetting", "Cloud URL");
                Program.objclsComm.strlstDevIPAddress.Clear();
                Program.objclsComm.strlstDevID.Clear();

                for (int i = 1; i <= int_CreateDeviceSaveIndex; i++)
                {
                    Program.objclsComm.strlstDevIPAddress.Add(ini.IniReadValue("Device" + " " + i, "IP Address"));
                    Program.objclsComm.strlstDevID.Add(ini.IniReadValue("Device" + " " + i, "Device Id"));

                }
            }
            catch (Exception ex)
            {
                Logger.Error("fnReadCreateDevice()" + ex.Message);
            }
            Logger.Info("Exiting into fnReadCreateDevice()");
        }
        int iIPIndex = 0;
        public void fnCreateThreads()
        {
            Program.objclsComm.blnStartDAQ = true;
            CheckAppRunning.Classes.clsAdvancedHMI objAdvanceHMI = new Classes.clsAdvancedHMI();
            objAdvanceHMI.strURLToExecute =Program.objclsComm.strBasicURL + Program.objclsComm.strAddDataURL + Program.objclsComm.strCustomerName + "&deviceID=" + Program.objclsComm.strlstDevID[iIPIndex];
            objAdvanceHMI.fnConnectToDevice(Program.objclsComm.strlstDevIPAddress[iIPIndex]);
            objAdvanceHMI.fnGetparamList(Program.objclsComm.strlstDevID[iIPIndex]);
        }

    }
}
