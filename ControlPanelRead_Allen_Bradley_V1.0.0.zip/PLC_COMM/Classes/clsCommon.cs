﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;

namespace CheckAppRunning.Classes
{
    class clsCommon
    {
        public clsIniFiles objReadWriteConfig;
        public List<string> strlstDevIPAddress = new List<string>();
        public List<string> strlstDevID = new List<string>();
        public List<string> strlstCustomerName = new List<string>();
        public bool blnStartDAQ = false;
        public string[] strarrParamValues;
        public string strBasicURL = string.Empty;
        public string strDeviceIDConst = "&deviceID=";
        public string strCreateDeviceURL = "createdevice?dbName=";
        public string strAddDataURL = "addfeaturedata?dbName=";
        public string strDeviceActivityURL = "addactivitydata?dbName=";
        public string strAddAlarmURL = "addalarmdata?dbName=";
        public string strAddProdDataURL = "addproductiondata?dbName=";
        public string strUpdateFeatureDataURL = "updatenameunit?dbName=";
        public bool IsInternetConnection = false;
        public List<string> strlstUrlToExecute = new List<string>();
        public List<byte[]> bytlstarray = new List<byte[]>();
        public int iUpdateFreq = 500;
        public string strCustomerName = string.Empty;
        public string fngetTimeSpan()
        {
            // epoch timestamp.
            TimeSpan t = DateTime.UtcNow - new DateTime(1970, 1, 1);
            int secondsSinceEpoch = (int)t.TotalSeconds;

          return  secondsSinceEpoch.ToString()+".00";
        }

        public bool CheckForInternetConnection()
        {
            try
            {
                using (var client = new WebClient())
                {
                    using (var stream = client.OpenRead("http://www.google.com"))//http://www.smsjust.com 
                    {
                        IsInternetConnection = true;
                        return IsInternetConnection;
                    }
                }
            }
            catch
            {
                IsInternetConnection = false;
                return IsInternetConnection;
            }
        }

      
    }
}
