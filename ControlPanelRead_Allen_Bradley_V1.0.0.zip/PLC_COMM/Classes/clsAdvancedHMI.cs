﻿using AdvancedHMIDrivers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace CheckAppRunning.Classes
{
    class clsAdvancedHMI
    {
        EthernetIPforSLCMicroComm MyMicroLogix = new EthernetIPforSLCMicroComm();
        public string strURLToExecute = string.Empty;
        public List<string> strparamTags = new List<string>();

        public string DeviceId = string.Empty;
      //  public string CustomerName = string.Empty;
        public string postData;
        public int index = 001;
        public byte[] data;
        public bool fnConnectToDevice(string strIPAddress)
        {
            Logger.Info("Entering into fnConnectToDevice()");
            try
            {
                MyMicroLogix.IPAddress = strIPAddress;//[PPM] Temp. Hide
                Logger.Info("Exiting into fnConnectToDevice()");
                return true;

            }
            catch (Exception ex)
            {
                Logger.Error("fnConnectToDevice()" + ex.Message);
                return false;
            }
        }

        public void fnGetparamList(string DeviceID)
        {
            Logger.Info("Entering into fnReadParameterConfig()");
            try
            {
                clsIniFiles ini = new clsIniFiles(Application.StartupPath + "\\ParameterConfig.ini");
                int int_ParaConfig_SaveIndex = Convert.ToInt32(ini.IniReadValue("Parameter Count", "Total Count"));
                strparamTags.Clear();
                for (int i = 1; i <= int_ParaConfig_SaveIndex; i++)
                {
                    if (DeviceID == (ini.IniReadValue("Parameter" + " " + i, "Device Id")))
                    {
                        strparamTags.Add(ini.IniReadValue("Parameter" + " " + i, "Parameter Tag"));
                    }
                }
                clsIniFiles inii = new clsIniFiles(Application.StartupPath + "\\CreateDeviceConfig.ini");
                int int_CreateDeviceSaveIndex = Convert.ToInt32(inii.IniReadValue("Device Count", "Total Count"));
                for (int i = 1; i <= int_CreateDeviceSaveIndex; i++)
                {
                    if (DeviceID == (inii.IniReadValue("Device" + " " + i, "Device Id")))
                    {
                        DeviceId = DeviceID;
                    }
                }

                Thread thr1 = new Thread(new ThreadStart(fnReadParams));
                thr1.Start();
            }
            catch (Exception ex)
            {
                Logger.Error("fnReadParameterConfig()" + ex.Message);
            }
            Logger.Info("Exiting into fnReadParameterConfig()");
        }

        private string[] fnGetparameterData()
        {
            Logger.Info("Entering into fnGetparameterData()");
            int iLen = strparamTags.Count;
            string[] strarrOutParamData = new string[iLen];
            try
            {
                Random rnd = new Random();
                try
                {
                    for (int i = 0; i < iLen; i++)
                    {
                        strarrOutParamData[i] = MyMicroLogix.ReadAny(strparamTags[i]);//""+ rnd.NextDouble(); //
                    }
                }
                catch (Exception ec)
                {
                    MessageBox.Show("Invalid tag name added.");
                    Logger.Error("fnConnectToDevice()" + ec.Message);
                }
            }
            catch (Exception ex)
            {
                Logger.Error("fnGetparameterData()" + ex.Message);
            }

            Logger.Info("Exiting into fnGetparameterData()");
            return strarrOutParamData;
        }

        private void fnAddData()
        {
            Logger.Info("Entering into fnAddData()");
            try
            {

                Logger.Error("URL Executed = " + strURLToExecute);

                //  postData = "[\"001," + lblreceivedData.Text + "," + fnGetCurrentLongTime() + "\"]";
                postData = "[\"";
                for (int i = 0; i < strparamTags.Count; i++)
                {
                    // string data = strparamTags[i] + "," + Program.objclsComm.strarrParamValues[i];
                    postData += string.Format("{0:000}", index) + "," + Program.objclsComm.strarrParamValues[i]+",";
                    index++;
                }
                string date = Program.objclsComm.fngetTimeSpan();
                postData += date;
                postData += "\"]";
                Logger.Error("Upload Data = "+postData);
                data = Encoding.ASCII.GetBytes(postData);
           
                 fnSendDatawithURL();
            }
            catch (Exception ex)
            {
                Logger.Error("fnAddData()" + ex.Message);
            }
            Logger.Info("Exiting into fnAddData()");
        }
        private void fnReadParams()
        {
            try
            {
                while (Program.objclsComm.blnStartDAQ)
                {
                    index = 001;
                    Program.objclsComm.strarrParamValues = fnGetparameterData();
                    fnAddData();
                    Thread.Sleep(Program.objclsComm.iUpdateFreq);
                }
            }
            catch(Exception ex)
            {
                Logger.Error(ex.Message);
            }
        }

        public void fnExecuteURL()
        {
            Logger.Info("Entering into fnExecuteURL()");
            try
            {
                //   string strSMSGatewayLink = strLink;
              //  Thread.Sleep(10);
                // creating web request to send sms
                HttpWebRequest _createRequest = (HttpWebRequest)WebRequest.Create(strURLToExecute);
                // getting response of sms
                HttpWebResponse myResp = (HttpWebResponse)_createRequest.GetResponse();
                System.IO.StreamReader _responseStreamReader = new System.IO.StreamReader(myResp.GetResponseStream());
                string responseString = _responseStreamReader.ReadToEnd();

                _responseStreamReader.Close();
                myResp.Close();
                Thread.Sleep(10);
            }
            catch (Exception ce)
            {
                MessageBox.Show("Info Not Sent! Exception " + ce.ToString());
                Logger.Error("fnExecuteURL()" + ce.Message);
            }
            Logger.Info("Exiting into fnExecuteURL()");
        }

        public void fnSendDatawithURL()
        {
            Logger.Info("Entering into fnSendDatawithURL()");
            try
            {
               // HttpWebRequest _createRequest = (HttpWebRequest)WebRequest.Create(Program.objAdvanceHMI.strURLToExecute);//31.10.2017 [PPM]
                HttpWebRequest _createRequest = (HttpWebRequest)WebRequest.Create(strURLToExecute);
                _createRequest.Method = "POST";
                _createRequest.ContentType = "text/plain;charset=UTF-8";
                _createRequest.ContentLength = data.Length;

                using (var stream = _createRequest.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }
                HttpWebResponse myResp = (HttpWebResponse)_createRequest.GetResponse();
                System.IO.StreamReader _responseStreamReader = new System.IO.StreamReader(myResp.GetResponseStream());
                string responseString = _responseStreamReader.ReadToEnd();

                _responseStreamReader.Close();
                myResp.Close();
                if (myResp.StatusDescription != "OK" && myResp.StatusDescription != "SUCCESS")
                {
                    Program.objclsComm.strlstUrlToExecute.Add(strURLToExecute);
                    Program.objclsComm.bytlstarray.Add(data);
                }
              else  if (Program.objclsComm.strlstUrlToExecute.Count != 0 && Program.objclsComm.IsInternetConnection)
                {
                    Program.objclsComm.IsInternetConnection = false;
                    fnSendQueuedData();
                }
                Thread.Sleep(10);
            }
            catch (Exception ce)
            {
                Logger.Error("fnSendDatawithURL()" + ce.Message);
              //  MessageBox.Show("Info Not Sent! Exception " + ce.ToString());
            }
            Logger.Info("Exiting into fnSendDatawithURL()");
        }

        private void fnSendQueuedData()
        {
                try
                    {
                        Logger.Info("Entering into fnSendDatawithURL()");
                        for (int i = 0; i < Program.objclsComm.strlstUrlToExecute.Count; i++)
                        {
                            strURLToExecute = Program.objclsComm.strlstUrlToExecute[i];
                            data = Program.objclsComm.bytlstarray[i];
                            fnSendDatawithURL();
                        }
                            Program.objclsComm.strlstUrlToExecute.Clear();
                            Program.objclsComm.bytlstarray.Clear();
                    }
                    catch (Exception ec)
                    {
                            Logger.Error(ec.Message);
                    }
                        Program.objclsComm.IsInternetConnection = true;
                        Thread.Sleep(10);
                        Logger.Info("Exiting into fnSendQueuedData()");
        }
    }
}
