﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Windows.Forms;

namespace CheckAppRunning
{
    static class Program
    {
        static private TraceSwitch myTraceSwitch = new TraceSwitch("SwitchOne", "The first switch");
        public static Classes.clsCommon objclsComm;
        public static CheckAppRunning.Classes.clsAdvancedHMI objAdvanceHMI;
        static public TraceSwitch MyTraceSwitch
        {
            get { return myTraceSwitch; }
            set { myTraceSwitch = value; }
        }
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
            string strEnableLogging = System.Environment.GetEnvironmentVariable("TM_Logging", EnvironmentVariableTarget.Machine);
            objclsComm = new Classes.clsCommon();
            objclsComm.objReadWriteConfig = new clsIniFiles(Application.StartupPath + "\\HardwareConfig.config");
            objAdvanceHMI = new Classes.clsAdvancedHMI();
            if (strEnableLogging != null)
                MyTraceSwitch.Level = TraceLevel.Info;
            else
                MyTraceSwitch.Level = TraceLevel.Error;
            Logger.Info("------------------------Software Execution started---------------------------");

            ServiceBase[] ServicesToRun;
            ServicesToRun = new ServiceBase[]
            {
                new Service1()
            };
            ServiceBase.Run(ServicesToRun);
            Logger.Info("------------------------Stop Execution Software-------------------------------");
        }
    }
}
