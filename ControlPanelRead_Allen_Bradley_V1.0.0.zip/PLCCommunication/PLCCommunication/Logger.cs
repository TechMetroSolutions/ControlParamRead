﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PLCCommunication
{
    public static class Logger
    {
        public static void Error(string message)
        {
            try
            {
                if (Program.MyTraceSwitch.Level >= TraceLevel.Error)
                    WriteEntry(message, "Error");
            }
            catch { }
        }

        //public static void Error(Exception ex)
        //{
        //    WriteEntry(ex.Message, Properties.Resources.Error);
        //}

        public static void Warning(string message)
        {
            try
            {
                WriteEntry(message, "Warning");
            }
            catch { }
        }

        public static void Info(string message)
        {
            try
            {
                if (Program.MyTraceSwitch.Level >= TraceLevel.Info)
                    WriteEntry(message, "Info");
            }
            catch { }
        }

        private static void WriteEntry(string message, string type)
        {
            try
            {
                StackFrame stackFrame = new StackTrace().GetFrame(2);
                Trace.WriteLine(
                        string.Format("{0}, {1}, {2}, {3}",
                                      DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                                      type,
                                      stackFrame.GetMethod().Name,
                                      message));
                CheckRollover();
            }
            catch { }
        }
        public static void CheckRollover()
        {
            try
            {

                FileInfo currLog = new FileInfo("AppLogger.log");
                FileInfo f1 = new FileInfo("AppLogger1.log");
                FileInfo f2 = new FileInfo("AppLogger2.log");
                FileInfo f3 = new FileInfo("AppLogger3.log");
                FileInfo f4 = new FileInfo("AppLogger4.log");
                FileInfo f5 = new FileInfo("AppLogger5.log");

                if (currLog.Length > 10000000)
                {
                    if (f1.Exists)
                    {
                        if (f2.Exists)
                        {
                            if (f3.Exists)
                            {
                                if (f4.Exists)
                                {
                                    if (f5.Exists)
                                    {
                                        if (f1.LastWriteTime < f5.LastWriteTime)
                                        {
                                            f1.Delete();
                                            currLog.CopyTo("AppLogger1.log");
                                        }
                                        else if (f2.LastWriteTime < f1.LastWriteTime)
                                        {
                                            f2.Delete();
                                            currLog.CopyTo("AppLogger2.log");
                                        }
                                        else if (f3.LastWriteTime < f2.LastWriteTime)
                                        {
                                            f3.Delete();
                                            currLog.CopyTo("AppLogger3.log");
                                        }
                                        else if (f4.LastWriteTime < f3.LastWriteTime)
                                        {
                                            f4.Delete();
                                            currLog.CopyTo("AppLogger4.log");
                                        }
                                        else if (f5.LastWriteTime < f4.LastWriteTime)
                                        {
                                            f5.Delete();
                                            currLog.CopyTo("AppLogger5.log");
                                        }
                                    }
                                    // f5
                                    else
                                    {
                                        currLog.CopyTo("AppLogger5.log");
                                    }
                                }
                                else
                                {
                                    currLog.CopyTo("AppLogger4.log");
                                }
                            }
                            else
                            {
                                currLog.CopyTo("AppLogger3.log");
                            }
                        }
                        else
                        {
                            currLog.CopyTo("AppLogger2.log");
                        }
                    }
                    else
                    {
                        currLog.CopyTo("AppLogger1.log");
                    }
                    Trace.Flush();
                    Trace.Close();
                    currLog.Delete();
                }


            }
            catch (Exception)
            {
                //MessageBox.Show(ex.Message);
                // Logger.Error(ex.Message);
            }
        }


    }
}
