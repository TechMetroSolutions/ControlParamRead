﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLCCommunication
{
    static class Program
    {
       static private TraceSwitch myTraceSwitch = new TraceSwitch("SwitchOne", "The first switch");
        public static Classes.clsCommon objclsComm;
        public static PLCCommunication.Classes.clsAdvancedHMI objAdvanceHMI;
        static public TraceSwitch MyTraceSwitch
        {
            get { return myTraceSwitch; }
            set { myTraceSwitch = value; }
        }
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.SetCompatibleTextRenderingDefault(false);
            string strEnableLogging = System.Environment.GetEnvironmentVariable("TM_Logging", EnvironmentVariableTarget.Machine);
            objclsComm = new Classes.clsCommon();
            objclsComm.objReadWriteConfig = new clsIniFiles(Application.StartupPath + "\\HardwareConfig.config");
            objAdvanceHMI = new Classes.clsAdvancedHMI();
            if (strEnableLogging != null)
                MyTraceSwitch.Level = TraceLevel.Info;
            else
                MyTraceSwitch.Level = TraceLevel.Error;
            Program.objclsComm.objFrmLogin = new FrmLogin();
            Logger.Info("------------------------Software Execution started---------------------------");
            Application.EnableVisualStyles();         
            Application.Run(Program.objclsComm.objFrmLogin);
            Logger.Info("------------------------Software Execution End-------------------------------");

        }
    }
}
