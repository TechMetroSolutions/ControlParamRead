﻿namespace PLCCommunication
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.lblCreateDeviceIpAddress = new System.Windows.Forms.Label();
            this.lblCreateDeviceDeviceId = new System.Windows.Forms.Label();
            this.lblCreateDevicePortNo = new System.Windows.Forms.Label();
            this.lblCreateDeviceMachineName = new System.Windows.Forms.Label();
            this.txtIPAddress = new System.Windows.Forms.TextBox();
            this.txtPortNo = new System.Windows.Forms.TextBox();
            this.txtDeviceId = new System.Windows.Forms.TextBox();
            this.txtMachineName = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtParameterCount = new System.Windows.Forms.TextBox();
            this.lblCreateDeviceNoOfParaCount = new System.Windows.Forms.Label();
            this.txtCustomerNameCreateDevice = new System.Windows.Forms.TextBox();
            this.lblCreateDeviceCustomerName = new System.Windows.Forms.Label();
            this.GridViewCreateDevice = new System.Windows.Forms.DataGridView();
            this.clmDeviceIndex = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmControlMake = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmControlModel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmIPAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmPortNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmCustomerName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmDeviceId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmDeviceName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmMachineName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmParameterCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnRemoveDevice = new System.Windows.Forms.Button();
            this.btnCreateDeviceEdit = new System.Windows.Forms.Button();
            this.btnCreateDeviceAdd = new System.Windows.Forms.Button();
            this.cmbControlModel = new System.Windows.Forms.ComboBox();
            this.cmbControlMake = new System.Windows.Forms.ComboBox();
            this.btnCreateDevice = new System.Windows.Forms.Button();
            this.lblCreateDeviceControllerMake = new System.Windows.Forms.Label();
            this.lblCreateDeviceControllerModel = new System.Windows.Forms.Label();
            this.txtDeviceName = new System.Windows.Forms.TextBox();
            this.lblCreateDeviceDeviceName = new System.Windows.Forms.Label();
            this.btnUpdateFeature = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cmbDeviceId = new System.Windows.Forms.ComboBox();
            this.txtParameterName = new System.Windows.Forms.TextBox();
            this.txtParameterUnit = new System.Windows.Forms.TextBox();
            this.btnRemoveParameter = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnAddParameters = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtParaConfigMachineName = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtParameterTag = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.GridViewParameterConfig = new System.Windows.Forms.DataGridView();
            this.clmParameterFileIndex = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmParameterName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmParameterUnit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmParameterTag = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnExit = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.TBCommanSetting = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.btnSaveCommanSetting = new System.Windows.Forms.Button();
            this.txtCloudURL = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtReadFreq = new System.Windows.Forms.TextBox();
            this.txtWriteFreq = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.TBCreateDevice = new System.Windows.Forms.TabPage();
            this.TBParameterConfig = new System.Windows.Forms.TabPage();
            this.btnServiceStart = new System.Windows.Forms.Button();
            this.btnServiceStop = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridViewCreateDevice)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridViewParameterConfig)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.TBCommanSetting.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.TBCreateDevice.SuspendLayout();
            this.TBParameterConfig.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblCreateDeviceIpAddress
            // 
            this.lblCreateDeviceIpAddress.AutoSize = true;
            this.lblCreateDeviceIpAddress.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCreateDeviceIpAddress.Location = new System.Drawing.Point(122, 62);
            this.lblCreateDeviceIpAddress.Name = "lblCreateDeviceIpAddress";
            this.lblCreateDeviceIpAddress.Size = new System.Drawing.Size(83, 21);
            this.lblCreateDeviceIpAddress.TabIndex = 0;
            this.lblCreateDeviceIpAddress.Text = "IP Address";
            // 
            // lblCreateDeviceDeviceId
            // 
            this.lblCreateDeviceDeviceId.AutoSize = true;
            this.lblCreateDeviceDeviceId.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCreateDeviceDeviceId.Location = new System.Drawing.Point(132, 92);
            this.lblCreateDeviceDeviceId.Name = "lblCreateDeviceDeviceId";
            this.lblCreateDeviceDeviceId.Size = new System.Drawing.Size(73, 21);
            this.lblCreateDeviceDeviceId.TabIndex = 0;
            this.lblCreateDeviceDeviceId.Text = "Device Id";
            // 
            // lblCreateDevicePortNo
            // 
            this.lblCreateDevicePortNo.AutoSize = true;
            this.lblCreateDevicePortNo.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCreateDevicePortNo.Location = new System.Drawing.Point(460, 62);
            this.lblCreateDevicePortNo.Name = "lblCreateDevicePortNo";
            this.lblCreateDevicePortNo.Size = new System.Drawing.Size(64, 21);
            this.lblCreateDevicePortNo.TabIndex = 0;
            this.lblCreateDevicePortNo.Text = "Port No";
            // 
            // lblCreateDeviceMachineName
            // 
            this.lblCreateDeviceMachineName.AutoSize = true;
            this.lblCreateDeviceMachineName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCreateDeviceMachineName.Location = new System.Drawing.Point(90, 124);
            this.lblCreateDeviceMachineName.Name = "lblCreateDeviceMachineName";
            this.lblCreateDeviceMachineName.Size = new System.Drawing.Size(115, 21);
            this.lblCreateDeviceMachineName.TabIndex = 0;
            this.lblCreateDeviceMachineName.Text = "Machine Name";
            // 
            // txtIPAddress
            // 
            this.txtIPAddress.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIPAddress.Location = new System.Drawing.Point(211, 57);
            this.txtIPAddress.Name = "txtIPAddress";
            this.txtIPAddress.Size = new System.Drawing.Size(176, 29);
            this.txtIPAddress.TabIndex = 2;
            // 
            // txtPortNo
            // 
            this.txtPortNo.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtPortNo.Location = new System.Drawing.Point(530, 57);
            this.txtPortNo.Name = "txtPortNo";
            this.txtPortNo.Size = new System.Drawing.Size(176, 29);
            this.txtPortNo.TabIndex = 3;
            // 
            // txtDeviceId
            // 
            this.txtDeviceId.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDeviceId.Location = new System.Drawing.Point(211, 89);
            this.txtDeviceId.Name = "txtDeviceId";
            this.txtDeviceId.Size = new System.Drawing.Size(176, 29);
            this.txtDeviceId.TabIndex = 4;
            // 
            // txtMachineName
            // 
            this.txtMachineName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMachineName.Location = new System.Drawing.Point(211, 121);
            this.txtMachineName.Name = "txtMachineName";
            this.txtMachineName.Size = new System.Drawing.Size(176, 29);
            this.txtMachineName.TabIndex = 6;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtParameterCount);
            this.groupBox1.Controls.Add(this.lblCreateDeviceNoOfParaCount);
            this.groupBox1.Controls.Add(this.txtCustomerNameCreateDevice);
            this.groupBox1.Controls.Add(this.lblCreateDeviceCustomerName);
            this.groupBox1.Controls.Add(this.GridViewCreateDevice);
            this.groupBox1.Controls.Add(this.btnRemoveDevice);
            this.groupBox1.Controls.Add(this.btnCreateDeviceEdit);
            this.groupBox1.Controls.Add(this.btnCreateDeviceAdd);
            this.groupBox1.Controls.Add(this.cmbControlModel);
            this.groupBox1.Controls.Add(this.cmbControlMake);
            this.groupBox1.Controls.Add(this.txtIPAddress);
            this.groupBox1.Controls.Add(this.btnCreateDevice);
            this.groupBox1.Controls.Add(this.lblCreateDeviceControllerMake);
            this.groupBox1.Controls.Add(this.lblCreateDeviceIpAddress);
            this.groupBox1.Controls.Add(this.lblCreateDeviceControllerModel);
            this.groupBox1.Controls.Add(this.txtPortNo);
            this.groupBox1.Controls.Add(this.lblCreateDevicePortNo);
            this.groupBox1.Controls.Add(this.txtMachineName);
            this.groupBox1.Controls.Add(this.txtDeviceName);
            this.groupBox1.Controls.Add(this.txtDeviceId);
            this.groupBox1.Controls.Add(this.lblCreateDeviceDeviceName);
            this.groupBox1.Controls.Add(this.lblCreateDeviceMachineName);
            this.groupBox1.Controls.Add(this.lblCreateDeviceDeviceId);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(6, 9);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(965, 497);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Comman Configration Setting";
            // 
            // txtParameterCount
            // 
            this.txtParameterCount.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtParameterCount.Location = new System.Drawing.Point(530, 153);
            this.txtParameterCount.Name = "txtParameterCount";
            this.txtParameterCount.Size = new System.Drawing.Size(176, 29);
            this.txtParameterCount.TabIndex = 8;
            // 
            // lblCreateDeviceNoOfParaCount
            // 
            this.lblCreateDeviceNoOfParaCount.AutoSize = true;
            this.lblCreateDeviceNoOfParaCount.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCreateDeviceNoOfParaCount.Location = new System.Drawing.Point(351, 156);
            this.lblCreateDeviceNoOfParaCount.Name = "lblCreateDeviceNoOfParaCount";
            this.lblCreateDeviceNoOfParaCount.Size = new System.Drawing.Size(173, 21);
            this.lblCreateDeviceNoOfParaCount.TabIndex = 24;
            this.lblCreateDeviceNoOfParaCount.Text = "No.Of Parameter Count";
            // 
            // txtCustomerNameCreateDevice
            // 
            this.txtCustomerNameCreateDevice.Enabled = false;
            this.txtCustomerNameCreateDevice.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerNameCreateDevice.Location = new System.Drawing.Point(530, 121);
            this.txtCustomerNameCreateDevice.Name = "txtCustomerNameCreateDevice";
            this.txtCustomerNameCreateDevice.Size = new System.Drawing.Size(176, 29);
            this.txtCustomerNameCreateDevice.TabIndex = 7;
            // 
            // lblCreateDeviceCustomerName
            // 
            this.lblCreateDeviceCustomerName.AutoSize = true;
            this.lblCreateDeviceCustomerName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCreateDeviceCustomerName.Location = new System.Drawing.Point(400, 124);
            this.lblCreateDeviceCustomerName.Name = "lblCreateDeviceCustomerName";
            this.lblCreateDeviceCustomerName.Size = new System.Drawing.Size(124, 21);
            this.lblCreateDeviceCustomerName.TabIndex = 22;
            this.lblCreateDeviceCustomerName.Text = "Customer Name";
            // 
            // GridViewCreateDevice
            // 
            this.GridViewCreateDevice.AllowUserToAddRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GridViewCreateDevice.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.GridViewCreateDevice.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridViewCreateDevice.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clmDeviceIndex,
            this.clmControlMake,
            this.clmControlModel,
            this.clmIPAddress,
            this.clmPortNo,
            this.clmCustomerName,
            this.clmDeviceId,
            this.clmDeviceName,
            this.clmMachineName,
            this.clmParameterCount});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.GridViewCreateDevice.DefaultCellStyle = dataGridViewCellStyle2;
            this.GridViewCreateDevice.Location = new System.Drawing.Point(6, 187);
            this.GridViewCreateDevice.Name = "GridViewCreateDevice";
            this.GridViewCreateDevice.ReadOnly = true;
            this.GridViewCreateDevice.Size = new System.Drawing.Size(946, 249);
            this.GridViewCreateDevice.TabIndex = 14;
            this.GridViewCreateDevice.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GridViewCreateDevice_CellClick);
            // 
            // clmDeviceIndex
            // 
            this.clmDeviceIndex.HeaderText = "Device Index";
            this.clmDeviceIndex.Name = "clmDeviceIndex";
            this.clmDeviceIndex.ReadOnly = true;
            this.clmDeviceIndex.Visible = false;
            // 
            // clmControlMake
            // 
            this.clmControlMake.HeaderText = "Control Make";
            this.clmControlMake.Name = "clmControlMake";
            this.clmControlMake.ReadOnly = true;
            // 
            // clmControlModel
            // 
            this.clmControlModel.HeaderText = "Control Model";
            this.clmControlModel.Name = "clmControlModel";
            this.clmControlModel.ReadOnly = true;
            // 
            // clmIPAddress
            // 
            this.clmIPAddress.HeaderText = "IP Address";
            this.clmIPAddress.Name = "clmIPAddress";
            this.clmIPAddress.ReadOnly = true;
            // 
            // clmPortNo
            // 
            this.clmPortNo.HeaderText = "Port No";
            this.clmPortNo.Name = "clmPortNo";
            this.clmPortNo.ReadOnly = true;
            // 
            // clmCustomerName
            // 
            this.clmCustomerName.HeaderText = "Customer Name";
            this.clmCustomerName.Name = "clmCustomerName";
            this.clmCustomerName.ReadOnly = true;
            // 
            // clmDeviceId
            // 
            this.clmDeviceId.HeaderText = "Device Id";
            this.clmDeviceId.Name = "clmDeviceId";
            this.clmDeviceId.ReadOnly = true;
            // 
            // clmDeviceName
            // 
            this.clmDeviceName.HeaderText = "Device Name";
            this.clmDeviceName.Name = "clmDeviceName";
            this.clmDeviceName.ReadOnly = true;
            // 
            // clmMachineName
            // 
            this.clmMachineName.HeaderText = "Machine Name";
            this.clmMachineName.Name = "clmMachineName";
            this.clmMachineName.ReadOnly = true;
            // 
            // clmParameterCount
            // 
            this.clmParameterCount.HeaderText = "Parameter Count";
            this.clmParameterCount.Name = "clmParameterCount";
            this.clmParameterCount.ReadOnly = true;
            // 
            // btnRemoveDevice
            // 
            this.btnRemoveDevice.Enabled = false;
            this.btnRemoveDevice.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemoveDevice.ForeColor = System.Drawing.Color.Black;
            this.btnRemoveDevice.Location = new System.Drawing.Point(723, 99);
            this.btnRemoveDevice.Name = "btnRemoveDevice";
            this.btnRemoveDevice.Size = new System.Drawing.Size(83, 32);
            this.btnRemoveDevice.TabIndex = 11;
            this.btnRemoveDevice.Text = "Remove";
            this.btnRemoveDevice.UseVisualStyleBackColor = true;
            this.btnRemoveDevice.Click += new System.EventHandler(this.btnCreateDeviceRemove_Click);
            // 
            // btnCreateDeviceEdit
            // 
            this.btnCreateDeviceEdit.Enabled = false;
            this.btnCreateDeviceEdit.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateDeviceEdit.ForeColor = System.Drawing.Color.Black;
            this.btnCreateDeviceEdit.Location = new System.Drawing.Point(723, 62);
            this.btnCreateDeviceEdit.Name = "btnCreateDeviceEdit";
            this.btnCreateDeviceEdit.Size = new System.Drawing.Size(83, 32);
            this.btnCreateDeviceEdit.TabIndex = 10;
            this.btnCreateDeviceEdit.Text = "Edit";
            this.btnCreateDeviceEdit.UseVisualStyleBackColor = true;
            this.btnCreateDeviceEdit.Click += new System.EventHandler(this.btnCreateDeviceEdit_Click);
            // 
            // btnCreateDeviceAdd
            // 
            this.btnCreateDeviceAdd.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateDeviceAdd.ForeColor = System.Drawing.Color.Black;
            this.btnCreateDeviceAdd.Location = new System.Drawing.Point(723, 24);
            this.btnCreateDeviceAdd.Name = "btnCreateDeviceAdd";
            this.btnCreateDeviceAdd.Size = new System.Drawing.Size(83, 32);
            this.btnCreateDeviceAdd.TabIndex = 9;
            this.btnCreateDeviceAdd.Text = "Add";
            this.btnCreateDeviceAdd.UseVisualStyleBackColor = true;
            this.btnCreateDeviceAdd.Click += new System.EventHandler(this.btnCreateDeviceAdd_Click);
            // 
            // cmbControlModel
            // 
            this.cmbControlModel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbControlModel.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cmbControlModel.FormattingEnabled = true;
            this.cmbControlModel.Location = new System.Drawing.Point(530, 24);
            this.cmbControlModel.Name = "cmbControlModel";
            this.cmbControlModel.Size = new System.Drawing.Size(176, 29);
            this.cmbControlModel.TabIndex = 1;
            // 
            // cmbControlMake
            // 
            this.cmbControlMake.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbControlMake.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cmbControlMake.FormattingEnabled = true;
            this.cmbControlMake.Location = new System.Drawing.Point(211, 27);
            this.cmbControlMake.Name = "cmbControlMake";
            this.cmbControlMake.Size = new System.Drawing.Size(176, 29);
            this.cmbControlMake.TabIndex = 0;
            this.cmbControlMake.SelectedIndexChanged += new System.EventHandler(this.cmbControlMake_SelectedIndexChanged);
            // 
            // btnCreateDevice
            // 
            this.btnCreateDevice.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateDevice.ForeColor = System.Drawing.Color.Black;
            this.btnCreateDevice.Location = new System.Drawing.Point(820, 438);
            this.btnCreateDevice.Name = "btnCreateDevice";
            this.btnCreateDevice.Size = new System.Drawing.Size(132, 55);
            this.btnCreateDevice.TabIndex = 12;
            this.btnCreateDevice.Text = "Create Device";
            this.btnCreateDevice.UseVisualStyleBackColor = true;
            this.btnCreateDevice.Click += new System.EventHandler(this.btnCreateDevice_Click);
            // 
            // lblCreateDeviceControllerMake
            // 
            this.lblCreateDeviceControllerMake.AutoSize = true;
            this.lblCreateDeviceControllerMake.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCreateDeviceControllerMake.Location = new System.Drawing.Point(83, 30);
            this.lblCreateDeviceControllerMake.Name = "lblCreateDeviceControllerMake";
            this.lblCreateDeviceControllerMake.Size = new System.Drawing.Size(122, 21);
            this.lblCreateDeviceControllerMake.TabIndex = 0;
            this.lblCreateDeviceControllerMake.Text = "Controller Make";
            // 
            // lblCreateDeviceControllerModel
            // 
            this.lblCreateDeviceControllerModel.AutoSize = true;
            this.lblCreateDeviceControllerModel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCreateDeviceControllerModel.Location = new System.Drawing.Point(396, 30);
            this.lblCreateDeviceControllerModel.Name = "lblCreateDeviceControllerModel";
            this.lblCreateDeviceControllerModel.Size = new System.Drawing.Size(128, 21);
            this.lblCreateDeviceControllerModel.TabIndex = 0;
            this.lblCreateDeviceControllerModel.Text = "Controller Model";
            // 
            // txtDeviceName
            // 
            this.txtDeviceName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDeviceName.Location = new System.Drawing.Point(530, 89);
            this.txtDeviceName.Name = "txtDeviceName";
            this.txtDeviceName.Size = new System.Drawing.Size(176, 29);
            this.txtDeviceName.TabIndex = 5;
            // 
            // lblCreateDeviceDeviceName
            // 
            this.lblCreateDeviceDeviceName.AutoSize = true;
            this.lblCreateDeviceDeviceName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCreateDeviceDeviceName.Location = new System.Drawing.Point(422, 92);
            this.lblCreateDeviceDeviceName.Name = "lblCreateDeviceDeviceName";
            this.lblCreateDeviceDeviceName.Size = new System.Drawing.Size(102, 21);
            this.lblCreateDeviceDeviceName.TabIndex = 0;
            this.lblCreateDeviceDeviceName.Text = "Device Name";
            // 
            // btnUpdateFeature
            // 
            this.btnUpdateFeature.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateFeature.ForeColor = System.Drawing.Color.Black;
            this.btnUpdateFeature.Location = new System.Drawing.Point(693, 402);
            this.btnUpdateFeature.Name = "btnUpdateFeature";
            this.btnUpdateFeature.Size = new System.Drawing.Size(138, 55);
            this.btnUpdateFeature.TabIndex = 8;
            this.btnUpdateFeature.Text = "Update Feature";
            this.btnUpdateFeature.UseVisualStyleBackColor = true;
            this.btnUpdateFeature.Click += new System.EventHandler(this.btnUpdateFeature_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cmbDeviceId);
            this.groupBox2.Controls.Add(this.btnUpdateFeature);
            this.groupBox2.Controls.Add(this.txtParameterName);
            this.groupBox2.Controls.Add(this.txtParameterUnit);
            this.groupBox2.Controls.Add(this.btnRemoveParameter);
            this.groupBox2.Controls.Add(this.btnEdit);
            this.groupBox2.Controls.Add(this.btnAddParameters);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.txtParaConfigMachineName);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.txtParameterTag);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.GridViewParameterConfig);
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(59, 15);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(837, 467);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Parameter Configuration";
            // 
            // cmbDeviceId
            // 
            this.cmbDeviceId.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDeviceId.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cmbDeviceId.FormattingEnabled = true;
            this.cmbDeviceId.Location = new System.Drawing.Point(144, 19);
            this.cmbDeviceId.Name = "cmbDeviceId";
            this.cmbDeviceId.Size = new System.Drawing.Size(226, 29);
            this.cmbDeviceId.TabIndex = 0;
            this.cmbDeviceId.SelectedIndexChanged += new System.EventHandler(this.cmbDeviceId_SelectedIndexChanged);
            // 
            // txtParameterName
            // 
            this.txtParameterName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtParameterName.Location = new System.Drawing.Point(144, 55);
            this.txtParameterName.Name = "txtParameterName";
            this.txtParameterName.Size = new System.Drawing.Size(226, 29);
            this.txtParameterName.TabIndex = 2;
            // 
            // txtParameterUnit
            // 
            this.txtParameterUnit.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtParameterUnit.Location = new System.Drawing.Point(501, 55);
            this.txtParameterUnit.Name = "txtParameterUnit";
            this.txtParameterUnit.Size = new System.Drawing.Size(233, 29);
            this.txtParameterUnit.TabIndex = 3;
            // 
            // btnRemoveParameter
            // 
            this.btnRemoveParameter.Enabled = false;
            this.btnRemoveParameter.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemoveParameter.ForeColor = System.Drawing.Color.Black;
            this.btnRemoveParameter.Location = new System.Drawing.Point(748, 92);
            this.btnRemoveParameter.Name = "btnRemoveParameter";
            this.btnRemoveParameter.Size = new System.Drawing.Size(83, 32);
            this.btnRemoveParameter.TabIndex = 7;
            this.btnRemoveParameter.Text = "Remove";
            this.btnRemoveParameter.UseVisualStyleBackColor = true;
            this.btnRemoveParameter.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Enabled = false;
            this.btnEdit.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.ForeColor = System.Drawing.Color.Black;
            this.btnEdit.Location = new System.Drawing.Point(748, 55);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(83, 32);
            this.btnEdit.TabIndex = 6;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnAddParameters
            // 
            this.btnAddParameters.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddParameters.ForeColor = System.Drawing.Color.Black;
            this.btnAddParameters.Location = new System.Drawing.Point(748, 17);
            this.btnAddParameters.Name = "btnAddParameters";
            this.btnAddParameters.Size = new System.Drawing.Size(83, 32);
            this.btnAddParameters.TabIndex = 5;
            this.btnAddParameters.Text = "Add";
            this.btnAddParameters.UseVisualStyleBackColor = true;
            this.btnAddParameters.Click += new System.EventHandler(this.btnAddParameters_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(382, 60);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(115, 21);
            this.label8.TabIndex = 0;
            this.label8.Text = "Parameter Unit";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(382, 22);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(115, 21);
            this.label16.TabIndex = 0;
            this.label16.Text = "Machine Name";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(28, 93);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(111, 21);
            this.label10.TabIndex = 0;
            this.label10.Text = "Parameter Tag";
            // 
            // txtParaConfigMachineName
            // 
            this.txtParaConfigMachineName.Enabled = false;
            this.txtParaConfigMachineName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtParaConfigMachineName.Location = new System.Drawing.Point(501, 19);
            this.txtParaConfigMachineName.Name = "txtParaConfigMachineName";
            this.txtParaConfigMachineName.Size = new System.Drawing.Size(233, 29);
            this.txtParaConfigMachineName.TabIndex = 1;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(66, 23);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(73, 21);
            this.label17.TabIndex = 0;
            this.label17.Text = "Device Id";
            // 
            // txtParameterTag
            // 
            this.txtParameterTag.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtParameterTag.Location = new System.Drawing.Point(144, 90);
            this.txtParameterTag.Name = "txtParameterTag";
            this.txtParameterTag.Size = new System.Drawing.Size(226, 29);
            this.txtParameterTag.TabIndex = 4;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(11, 58);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(128, 21);
            this.label11.TabIndex = 0;
            this.label11.Text = "Parameter Name";
            // 
            // GridViewParameterConfig
            // 
            this.GridViewParameterConfig.AllowUserToAddRows = false;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GridViewParameterConfig.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.GridViewParameterConfig.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridViewParameterConfig.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clmParameterFileIndex,
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.clmParameterName,
            this.clmParameterUnit,
            this.clmParameterTag});
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.GridViewParameterConfig.DefaultCellStyle = dataGridViewCellStyle4;
            this.GridViewParameterConfig.Location = new System.Drawing.Point(12, 130);
            this.GridViewParameterConfig.Name = "GridViewParameterConfig";
            this.GridViewParameterConfig.ReadOnly = true;
            this.GridViewParameterConfig.Size = new System.Drawing.Size(819, 260);
            this.GridViewParameterConfig.TabIndex = 9;
            this.GridViewParameterConfig.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // clmParameterFileIndex
            // 
            this.clmParameterFileIndex.HeaderText = "Parameter File Index";
            this.clmParameterFileIndex.Name = "clmParameterFileIndex";
            this.clmParameterFileIndex.ReadOnly = true;
            this.clmParameterFileIndex.Visible = false;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Device Id";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Machine Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // clmParameterName
            // 
            this.clmParameterName.HeaderText = "Parameter Name";
            this.clmParameterName.Name = "clmParameterName";
            this.clmParameterName.ReadOnly = true;
            this.clmParameterName.Width = 150;
            // 
            // clmParameterUnit
            // 
            this.clmParameterUnit.HeaderText = "Parameter Unit";
            this.clmParameterUnit.Name = "clmParameterUnit";
            this.clmParameterUnit.ReadOnly = true;
            this.clmParameterUnit.Width = 150;
            // 
            // clmParameterTag
            // 
            this.clmParameterTag.HeaderText = "Parameter Tag";
            this.clmParameterTag.Name = "clmParameterTag";
            this.clmParameterTag.ReadOnly = true;
            this.clmParameterTag.Width = 150;
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.Black;
            this.btnExit.Location = new System.Drawing.Point(870, 567);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(138, 55);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.TBCommanSetting);
            this.tabControl1.Controls.Add(this.TBCreateDevice);
            this.tabControl1.Controls.Add(this.TBParameterConfig);
            this.tabControl1.Location = new System.Drawing.Point(25, 16);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(987, 538);
            this.tabControl1.TabIndex = 0;
            // 
            // TBCommanSetting
            // 
            this.TBCommanSetting.BackColor = System.Drawing.SystemColors.ControlDark;
            this.TBCommanSetting.Controls.Add(this.groupBox3);
            this.TBCommanSetting.Controls.Add(this.txtWriteFreq);
            this.TBCommanSetting.Controls.Add(this.label15);
            this.TBCommanSetting.Controls.Add(this.label7);
            this.TBCommanSetting.Location = new System.Drawing.Point(4, 22);
            this.TBCommanSetting.Name = "TBCommanSetting";
            this.TBCommanSetting.Size = new System.Drawing.Size(979, 512);
            this.TBCommanSetting.TabIndex = 2;
            this.TBCommanSetting.Text = "Common Setting";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtCustomerName);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.btnSaveCommanSetting);
            this.groupBox3.Controls.Add(this.txtCloudURL);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.txtReadFreq);
            this.groupBox3.ForeColor = System.Drawing.Color.White;
            this.groupBox3.Location = new System.Drawing.Point(145, 44);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(532, 299);
            this.groupBox3.TabIndex = 14;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Comman Setting";
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerName.Location = new System.Drawing.Point(148, 38);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(304, 29);
            this.txtCustomerName.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(18, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(124, 21);
            this.label4.TabIndex = 20;
            this.label4.Text = "Customer Name";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.label14.Location = new System.Drawing.Point(465, 80);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(48, 21);
            this.label14.TabIndex = 15;
            this.label14.Text = "mSec";
            // 
            // btnSaveCommanSetting
            // 
            this.btnSaveCommanSetting.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveCommanSetting.ForeColor = System.Drawing.Color.Black;
            this.btnSaveCommanSetting.Location = new System.Drawing.Point(355, 203);
            this.btnSaveCommanSetting.Name = "btnSaveCommanSetting";
            this.btnSaveCommanSetting.Size = new System.Drawing.Size(97, 47);
            this.btnSaveCommanSetting.TabIndex = 3;
            this.btnSaveCommanSetting.Text = "Save";
            this.btnSaveCommanSetting.UseVisualStyleBackColor = true;
            this.btnSaveCommanSetting.Click += new System.EventHandler(this.btnSaveCommanSetting_Click);
            // 
            // txtCloudURL
            // 
            this.txtCloudURL.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCloudURL.Location = new System.Drawing.Point(148, 121);
            this.txtCloudURL.Multiline = true;
            this.txtCloudURL.Name = "txtCloudURL";
            this.txtCloudURL.Size = new System.Drawing.Size(304, 76);
            this.txtCloudURL.TabIndex = 2;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(2, 79);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(140, 21);
            this.label6.TabIndex = 10;
            this.label6.Text = "Update Frequency ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(58, 121);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(84, 21);
            this.label9.TabIndex = 8;
            this.label9.Text = "Cloud URL";
            // 
            // txtReadFreq
            // 
            this.txtReadFreq.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReadFreq.Location = new System.Drawing.Point(148, 79);
            this.txtReadFreq.Name = "txtReadFreq";
            this.txtReadFreq.Size = new System.Drawing.Size(304, 29);
            this.txtReadFreq.TabIndex = 1;
            // 
            // txtWriteFreq
            // 
            this.txtWriteFreq.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWriteFreq.Location = new System.Drawing.Point(313, 363);
            this.txtWriteFreq.Name = "txtWriteFreq";
            this.txtWriteFreq.Size = new System.Drawing.Size(304, 29);
            this.txtWriteFreq.TabIndex = 12;
            this.txtWriteFreq.Visible = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.label15.Location = new System.Drawing.Point(629, 363);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(48, 21);
            this.label15.TabIndex = 15;
            this.label15.Text = "mSec";
            this.label15.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(181, 365);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(124, 21);
            this.label7.TabIndex = 9;
            this.label7.Text = "Write Frequency";
            this.label7.Visible = false;
            // 
            // TBCreateDevice
            // 
            this.TBCreateDevice.BackColor = System.Drawing.SystemColors.ControlDark;
            this.TBCreateDevice.Controls.Add(this.groupBox1);
            this.TBCreateDevice.Location = new System.Drawing.Point(4, 22);
            this.TBCreateDevice.Name = "TBCreateDevice";
            this.TBCreateDevice.Padding = new System.Windows.Forms.Padding(3);
            this.TBCreateDevice.Size = new System.Drawing.Size(979, 512);
            this.TBCreateDevice.TabIndex = 0;
            this.TBCreateDevice.Text = "Create Device";
            // 
            // TBParameterConfig
            // 
            this.TBParameterConfig.BackColor = System.Drawing.SystemColors.ControlDark;
            this.TBParameterConfig.Controls.Add(this.groupBox2);
            this.TBParameterConfig.Location = new System.Drawing.Point(4, 22);
            this.TBParameterConfig.Name = "TBParameterConfig";
            this.TBParameterConfig.Padding = new System.Windows.Forms.Padding(3);
            this.TBParameterConfig.Size = new System.Drawing.Size(979, 512);
            this.TBParameterConfig.TabIndex = 1;
            this.TBParameterConfig.Text = "Parameter Configuration";
            // 
            // btnServiceStart
            // 
            this.btnServiceStart.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnServiceStart.ForeColor = System.Drawing.Color.Black;
            this.btnServiceStart.Location = new System.Drawing.Point(1018, 106);
            this.btnServiceStart.Name = "btnServiceStart";
            this.btnServiceStart.Size = new System.Drawing.Size(156, 51);
            this.btnServiceStart.TabIndex = 2;
            this.btnServiceStart.Text = "Start Service";
            this.btnServiceStart.UseVisualStyleBackColor = true;
            this.btnServiceStart.Click += new System.EventHandler(this.btnServiceStart_Click);
            // 
            // btnServiceStop
            // 
            this.btnServiceStop.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnServiceStop.ForeColor = System.Drawing.Color.Black;
            this.btnServiceStop.Location = new System.Drawing.Point(1018, 38);
            this.btnServiceStop.Name = "btnServiceStop";
            this.btnServiceStop.Size = new System.Drawing.Size(156, 51);
            this.btnServiceStop.TabIndex = 1;
            this.btnServiceStop.Text = "Stop Service";
            this.btnServiceStop.UseVisualStyleBackColor = true;
            this.btnServiceStop.Click += new System.EventHandler(this.btnServiceStop_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(1180, 634);
            this.Controls.Add(this.btnServiceStop);
            this.Controls.Add(this.btnServiceStart);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btnExit);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Controller Data Acquisition";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridViewCreateDevice)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridViewParameterConfig)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.TBCommanSetting.ResumeLayout(false);
            this.TBCommanSetting.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.TBCreateDevice.ResumeLayout(false);
            this.TBParameterConfig.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblCreateDeviceIpAddress;
        private System.Windows.Forms.Label lblCreateDeviceDeviceId;
        private System.Windows.Forms.Label lblCreateDevicePortNo;
        private System.Windows.Forms.Label lblCreateDeviceMachineName;
        private System.Windows.Forms.TextBox txtIPAddress;
        private System.Windows.Forms.TextBox txtPortNo;
        private System.Windows.Forms.TextBox txtDeviceId;
        private System.Windows.Forms.TextBox txtMachineName;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnCreateDevice;
        private System.Windows.Forms.Button btnUpdateFeature;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtParameterName;
        private System.Windows.Forms.TextBox txtParameterUnit;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtParameterTag;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnAddParameters;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnRemoveParameter;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage TBCreateDevice;
        private System.Windows.Forms.TabPage TBParameterConfig;
        private System.Windows.Forms.TabPage TBCommanSetting;
        private System.Windows.Forms.ComboBox cmbControlModel;
        private System.Windows.Forms.ComboBox cmbControlMake;
        private System.Windows.Forms.Label lblCreateDeviceControllerMake;
        private System.Windows.Forms.Label lblCreateDeviceControllerModel;
        private System.Windows.Forms.TextBox txtCloudURL;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtWriteFreq;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtReadFreq;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnRemoveDevice;
        private System.Windows.Forms.Button btnCreateDeviceEdit;
        private System.Windows.Forms.Button btnCreateDeviceAdd;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnSaveCommanSetting;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox cmbDeviceId;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtParaConfigMachineName;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.DataGridView GridViewCreateDevice;
        private System.Windows.Forms.DataGridView GridViewParameterConfig;
        private System.Windows.Forms.TextBox txtDeviceName;
        private System.Windows.Forms.Label lblCreateDeviceDeviceName;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtCustomerNameCreateDevice;
        private System.Windows.Forms.Label lblCreateDeviceCustomerName;
        private System.Windows.Forms.TextBox txtParameterCount;
        private System.Windows.Forms.Label lblCreateDeviceNoOfParaCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmDeviceIndex;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmControlMake;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmControlModel;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmIPAddress;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmPortNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmCustomerName;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmDeviceId;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmDeviceName;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmMachineName;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmParameterCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmParameterFileIndex;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmParameterName;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmParameterUnit;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmParameterTag;
        private System.Windows.Forms.Button btnServiceStart;
        private System.Windows.Forms.Button btnServiceStop;
    }
}

