﻿using AutomatedSolutions.Win.Comm;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using ABLegacy = AutomatedSolutions.Win.Comm.AB.Legacy;

namespace PLCCommunication.Classes
{
    class clsASComm
    {
        #region Fields

        //
        // Create ASComm objects
        //
        /// <summary>
        /// 
        /// </summary>
        public ABLegacy.Net.Channel myChannel;
        /// <summary>
        /// 
        /// </summary>
        public ABLegacy.Device myDevice;
        /// <summary>
        /// 
        /// </summary>
        public ABLegacy.Group myGroup;
        /// <summary>
        /// 
        /// </summary>
        public ABLegacy.Item myItem;
        /// <summary>
        /// For transaction time reporting
        /// </summary>
        public Stopwatch sw;

        #endregion Fields
        public List<string> strparamTags = new List<string>();

        #region AS Comm Event Handlers   

        /// <summary>
        /// This is required to avoid cross threaded operation exception when updating the read textbox from a callback
        /// </summary>
        /// <param name="oo"></param>
        private void UpdateTextBox(string message)
        {
          //  invoke(new MethodInvoker(delegate { txtDataReceived.Text = message; }));
        }



        /// <summary>
        /// Async Read Callback routine  
        /// </summary>
        /// <param name="ar"></param>
        protected void OnAsyncReadComplete(IAsyncResult ar)
        {
            // Obtain the Item from the ar.AsyncState 
            Item myItem = (Item)ar.AsyncState;
            try
            {
                // Must call Item.EndRead to complete transaction
                myItem.EndRead(ar);
                // stop transaction timing
                sw.Stop();
                // Use invoke to update a form control from a callback  
                //  AddEvent(DateTime.Now.ToString("hh:mm:ss:fff") + " Successful read transaction, Item.Quality is " + myItem.Quality.ToString() + " (" + sw.ElapsedMilliseconds.ToString() + " mSec)");
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < myItem.Elements; i++)
                {
                    sb.Append(myItem.Values[i].ToString() + ",");
                }
                // Use invoke to update a form control from a callback
                UpdateTextBox(sb.ToString());
            }
            catch (Exception ex)
            {
                // Use invoke to update a form control from a callback
                // AddEvent(DateTime.Now.ToString("hh:mm:ss:fff") + " Read error, Item.Quality is " + myItem.Quality.ToString() + " (" + sw.ElapsedMilliseconds.ToString() + " mSec) " + ex.Message);
            }
        }


        /// <summary>
        /// Async Write Callback routine  
        /// </summary>
        /// <param name="ar"></param>
        protected void OnAsyncWriteComplete(IAsyncResult ar)
        {
            // Obtain the Item from the ar.AsyncState 
            Item myItem = (Item)(ar.AsyncState);
            try
            {
                // Must call Item.EndRead to complete transaction
                myItem.EndWrite(ar);
                sw.Stop();
                // Use invoke to update a form control from a callback
                // AddEvent(DateTime.Now.ToString("hh:mm:ss:fff") + " Successful write transaction (" + sw.ElapsedMilliseconds.ToString() + " mSec)");
            }
            catch (Exception ex)
            {
                // Use invoke to update a form control from a callback
                // AddEvent(DateTime.Now.ToString("hh:mm:ss:fff") + " Write error (" + sw.ElapsedMilliseconds.ToString() + " mSec) " + ex.Message);
            }
        }


        /// <summary>
        /// Channel Error event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="channelEventArgs"></param>
        public void channel_Error(object sender, AutomatedSolutions.Win.Comm.ChannelEventArgs evArgs)
        {
            MessageBox.Show(DateTime.Now.ToString("hh:mm:ss:fff") + " Channel.Error event fired: " + evArgs.Message);
        }

        /// <summary>
        /// Device Error event handler
        /// </summary>
        /// <param name="Sender"></param>
        /// <param name="evArgs"></param>
        public void device_Error(object Sender, AutomatedSolutions.Win.Comm.DeviceEventArgs evArgs)
        {
            MessageBox.Show(DateTime.Now.ToString("hh:mm:ss:fff") + " Device.Error event fired: " + evArgs.Message);
        }

        /// <summary>
        /// Item Error event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="evArgs"></param>
        public  void item_Error(object sender, AutomatedSolutions.Win.Comm.ItemEventArgs evArgs)
        {
            MessageBox.Show(DateTime.Now.ToString("hh:mm:ss:fff") + " Item.Error event fired: " + evArgs.Message);
        }

        /// <summary>
        /// Item DataChanged event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="evArgs"></param>
        public void item_DataChanged(object sender, EventArgs evArgs)
        {
            ABLegacy.Item item = (ABLegacy.Item)sender;
            //   MessageBox.Show(DateTime.Now.ToString("hh:mm:ss:fff") + " Item.DataChange event fired, Item.Quality is " + item.Quality.ToString());
            if (item.Quality == AutomatedSolutions.Win.Comm.Quality.GOOD)
            {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < myItem.Elements; i++)
                {
                    sb.Append(myItem.Values[i].ToString());
                }
               // txtDataReceived.Text = sb.ToString();
            }
        }


        #endregion

        public List<string> fnGetparamList(string DeviceID)
        {
            Logger.Info("Entering into fnReadParameterConfig()");
            try
            {
                clsIniFiles ini = new clsIniFiles(Application.StartupPath + "\\ParameterConfig.ini");
                int int_ParaConfig_SaveIndex = Convert.ToInt32(ini.IniReadValue("Parameter Count", "Total Count"));
                strparamTags.Clear();
                for (int i = 1; i <= int_ParaConfig_SaveIndex; i++)
                {
                    if (DeviceID == (ini.IniReadValue("Parameter" + " " + i, "Device Id")))
                    {
                        strparamTags.Add(ini.IniReadValue("Parameter" + " " + i, "Parameter Tag"));
                    }
                }                              
            }
            catch (Exception ex)
            {
                Logger.Error("fnReadParameterConfig()" + ex.Message);
            }
            Logger.Info("Exiting into fnReadParameterConfig()");
           return strparamTags;
        }

        public void fnReadSyncData()
        {
            while (Program.objclsComm.blnStartDAQ)
            {
                try
                {
                    #region Code 1   
                    ////  this.Cursor = Cursors.WaitCursor;
                    //sw = new Stopwatch();
                    //sw.Start();
                    //myItem.Read();
                    //sw.Stop();
                    //strarrParamValues = new string[myItem.Elements];
                    //// StringBuilder sb = new StringBuilder();
                    //for (int i = 0; i < myItem.Elements; i++)
                    //{
                    //    strarrParamValues[i] = myItem.Values[i].ToString();
                    //}
                    #endregion

                    #region Code 2 

                  Program.objclsComm.strarrParamValues = new string[myGroup.Items.Count];

                    for (int i = 0; i < myGroup.Items.Count; i++)
                    {
                        sw = new Stopwatch();
                        sw.Start();
                        myGroup.Items[i].Read();
                        sw.Stop();
                        Program.objclsComm.strarrParamValues[i] = myGroup.Items[i].Values[i].ToString();
                    }
                    #endregion
                }
                catch (Exception ex)
                {
                    MessageBox.Show(DateTime.Now.ToString("hh:mm:ss:fff") + " Read error, Item.Quality is " + myItem.Quality.ToString() + ": " + ex.Message); 
                }
                finally
                {
                }
                Thread.Sleep(10);
            }
        }
    }
}
