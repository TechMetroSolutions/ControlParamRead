﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
//**********************************************************************************************
//* AdvancedHMI Driver
//* http://www.advancedhmi.com
//* Ethernet/IP for ControlLogix
//*
//* Archie Jacobs
//* Manufacturing Automation, LLC
//* support@advancedhmi.com
//* 13-FEB-16
//*
//*
//* Copyright 2016 Archie Jacobs
//*
//* This class creates and interface between an Ethernet/IP driver and the AdvancedHMI
//* visual controls.
//*
//* NOTICE : If you received this code without a complete AdvancedHMI solution
//* please report to sales@advancedhmi.com
//*
//* Distributed under the GNU General Public License (www.gnu.org)
//*
//* This program is free software; you can redistribute it and/or
//* as published by the Free Software Foundation; either version 2
//* of the License, or (at your option) any later version.
//*
//* This program is distributed in the hope that it will be useful,
//* but WITHOUT ANY WARRANTY; without even the implied warranty of
//* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//* GNU General Public License for more details.

//* You should have received a copy of the GNU General Public License
//* along with this program; if not, write to the Free Software
//* Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
//*
//* 13-FEB-16 New architecture further separating UI element connection from driver
//*******************************************************************************************************
using System.ComponentModel.Design;
using AdvancedHMIDrivers;

//<CLSCompliant(True)>
[System.ComponentModel.DefaultEvent("DataReceived")]
[System.ComponentModel.DesignTimeVisible(true)]
[System.ComponentModel.ToolboxItem(true)]
public class EthernetIPforSLCMicroCom : MfgControl.AdvancedHMI.Drivers.AllenBradley.PCCC.EthernetIPforSLCMicroPLC5, System.ComponentModel.IComponent, System.ComponentModel.ISupportInitialize, System.Windows.Forms.IBindableComponent
{

    private static readonly object EventDisposed = new object();
  //  public event EventHandler System.ComponentModel.IComponent.Dispose();


	protected System.Threading.SynchronizationContext m_synchronizationContext;
    #region "Constructor"
    public EthernetIPforSLCMicroCom(System.ComponentModel.IContainer container) : base()
    {

        m_synchronizationContext = System.Windows.Forms.WindowsFormsSynchronizationContext.Current;
        //Required for Windows.Forms Class Composition Designer support
        container.Add(this);
    }

    public EthernetIPforSLCMicroCom() : base()
    {

        m_synchronizationContext = System.Windows.Forms.WindowsFormsSynchronizationContext.Current;
    }



    //Implements IDisposable.Dispose
    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            lock (this)
            {
                if (Site != null && Site.Container != null)
                {
                    Site.Container.Remove(this);
                }
                //If events IsNot Nothing Then
                //Dim handler As EventHandler = DirectCast(events(EventDisposed), EventHandler)
                //[PPM] 29.06.2017
                //if (Disposed != null)
                //{
                //    Disposed(this, EventArgs.Empty);
                //}
                //End If
            }
        }
        base.Dispose(disposing);
    }



    //'Component overrides dispose to clean up the component list.
    //Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    //    MyBase.Dispose(disposing)
    //End Sub
    #endregion

    #region "Properties"
    private string m_HostName;
    public override string IPAddress
    {
        get
        {
            if (!string.IsNullOrEmpty(m_HostName))
            {
                return m_HostName;
            }
            else
            {
                return base.IPAddress;
            }
        }
        set
        {
            if (!string.IsNullOrEmpty(value))
            {
                if (base.IPAddress != value)
                {
                    System.Net.IPAddress address = new System.Net.IPAddress(0);
                    if (System.Net.IPAddress.TryParse(value, out address))
                    {
                        base.IPAddress = value;
                        m_HostName = "";
                    }
                    else
                    {
                        System.Net.IPHostEntry IP = default(System.Net.IPHostEntry);
                        try
                        {
                            IP = System.Net.Dns.GetHostEntry(value);
                            for (int i = 0; i <= IP.AddressList.Length - 1; i++)
                            {
                                if (IP.AddressList[i].AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                                {
                                    base.IPAddress = IP.AddressList[i].ToString();
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                        }
                        m_HostName = value;
                    }
                    //End If
                }
            }
        }
    }

    //* Do this to hide it from the Property Window
    [System.ComponentModel.Browsable(false)]
    public override bool IsPLC5
    {
        get { return base.IsPLC5; }
        set { base.IsPLC5 = value; }
    }


    private System.ComponentModel.ISite m_site;
    [System.ComponentModel.Browsable(false), System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
    public virtual System.ComponentModel.ISite Site
    {
        get { return m_site; }
        set { m_site = value; }
    }


    [System.ComponentModel.Browsable(false), System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
    protected bool DesignMode
    {
        get
        {
            System.ComponentModel.ISite s = m_site;
            if (s == null)
            {
                return false;
            }
            else
            {
                return s.DesignMode;
            }
            // Return If((s Is Nothing), False, s.DesignMode)
        }
    }
    #endregion

    #region "Binding Properties"
    private System.Windows.Forms.BindingContext m_bindingContext;
    private System.Windows.Forms.ControlBindingsCollection m_dataBindings;
    [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
    public System.Windows.Forms.ControlBindingsCollection DataBindings
    {
        get
        {
            if ((m_dataBindings == null))
            {
                m_dataBindings = new System.Windows.Forms.ControlBindingsCollection(this);
            }
            return m_dataBindings;
        }
    }

    [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
    public System.Windows.Forms.BindingContext BindingContext
    {
        get
        {
            if (m_bindingContext == null)
            {
                m_bindingContext = new System.Windows.Forms.BindingContext();
            }
            return m_bindingContext;
        }
        // Throw New NotImplementedException()
        set { m_bindingContext = value; }
    }
    #endregion
    protected virtual object GetService(Type service)
    {
        System.ComponentModel.ISite s = Site;
        return ((s == null) ? null : s.GetService(service));
    }


    #region "Events"
    //Protected Overrides Sub OnConnectionClosed(ByVal e As EventArgs)
    //    'If m_SynchronizingObject IsNot Nothing AndAlso m_SynchronizingObject.InvokeRequired Then
    //    'Dim Parameters() As Object = {Me, EventArgs.Empty}
    //    If m_synchronizationContext IsNot Nothing Then  ' m_SynchronizingObject IsNot Nothing Then
    //        Try
    //            'm_SynchronizingObject.BeginInvoke(occd, Parameters)
    //            m_synchronizationContext.Post(AddressOf ConnectionClosedSync, EventArgs.Empty)
    //        Catch ex As Exception
    //        End Try
    //        'End If
    //    Else
    //        MyBase.OnConnectionClosed(e)
    //    End If
    //End Sub

    //Private Sub ConnectionClosedSync(ByVal e As Object)
    //    Dim e1 As EventArgs = DirectCast(e, EventArgs)
    //    MyBase.OnConnectionClosed(e1)
    //End Sub
    //'********************************************************************************************************************************


    //Protected Overrides Sub OnConnectionEstablished(ByVal e As EventArgs)
    //    'If m_SynchronizingObject IsNot Nothing AndAlso m_SynchronizingObject.InvokeRequired Then
    //    ' Dim Parameters() As Object = {Me, EventArgs.Empty}
    //    If m_synchronizationContext IsNot Nothing Then
    //        'If TypeOf (m_SynchronizingObject) Is System.Windows.Forms.Control AndAlso DirectCast(m_SynchronizingObject, System.Windows.Forms.Control).IsHandleCreated Then
    //        'm_SynchronizingObject.BeginInvoke(oced, Parameters)
    //        m_synchronizationContext.Post(AddressOf ConnectionEstabishedSync, EventArgs.Empty)
    //        'End If
    //        'End If
    //    Else
    //        MyBase.OnConnectionEstablished(e)
    //    End If
    //End Sub


    //Private Sub ConnectionEstabishedSync(ByVal e As Object)
    //    Dim e1 As EventArgs = DirectCast(e, EventArgs)
    //    MyBase.OnConnectionEstablished(e1)
    //End Sub


    protected override void OnDataReceived(MfgControl.AdvancedHMI.Drivers.Common.PlcComEventArgs e)
    {
        //If m_SynchronizingObject IsNot Nothing AndAlso m_SynchronizingObject.InvokeRequired Then
        if (m_synchronizationContext != null)
        {
            //m_SynchronizingObject.BeginInvoke(drsd, New Object() {Me, e})
            m_synchronizationContext.Post(DataReceivedSync, e);
        }
        else
        {
            base.OnDataReceived(e);
        }
    }


    private void DataReceivedSync(object e)
    {
        try
        {
            MfgControl.AdvancedHMI.Drivers.Common.PlcComEventArgs e1 = (MfgControl.AdvancedHMI.Drivers.Common.PlcComEventArgs)e;
            base.OnDataReceived(e1);
        }
        catch (Exception ex)
        {
            //Dim dbg = 0
        }
    }


    //***********************************************************************************************************
    protected override void OnComError(MfgControl.AdvancedHMI.Drivers.Common.PlcComEventArgs e)
    {
        //If m_SynchronizingObject IsNot Nothing AndAlso m_SynchronizingObject.InvokeRequired Then
        if (m_synchronizationContext != null)
        {
            //Dim Parameters() As Object = {Me, e}
            //m_SynchronizingObject.BeginInvoke(errorsd, Parameters)
            m_synchronizationContext.Post(ErrorReceivedSync, e);
        }
        else
        {
            base.OnComError(e);
        }
    }

    private void ErrorReceivedSync(object e)
    {
        MfgControl.AdvancedHMI.Drivers.Common.PlcComEventArgs e1 = (MfgControl.AdvancedHMI.Drivers.Common.PlcComEventArgs)e;
        base.OnComError(e1);
    }
    //***********************************************************************************************************


    //***********************************************************************************************************
    protected override void OnSubscriptionDataReceived(MfgControl.AdvancedHMI.Drivers.Common.SubscriptionEventArgs e)
    {
        //If m_SynchronizingObject IsNot Nothing AndAlso m_SynchronizingObject.InvokeRequired Then
        if (m_synchronizationContext != null)
        {
            //Dim Parameters() As Object = {Me, e}
            //m_SynchronizingObject.BeginInvoke(e.dlgCallBack, Parameters)
            //If e.Values isnot Nothing andalso e.Values .Count>) andalso e.Values(0) Is Nothing Then
            //    Dim dbg = 0
            //End If
            m_synchronizationContext.Post(DataRecSync, e);
        }
        else
        {
            base.OnSubscriptionDataReceived(e);
        }
    }

    private void DataRecSync(object e)
    {
        MfgControl.AdvancedHMI.Drivers.Common.SubscriptionEventArgs e1 = (MfgControl.AdvancedHMI.Drivers.Common.SubscriptionEventArgs)e;
        e1.dlgCallBack(this, e1);
    }

    #endregion

    #region "IniFileHandling"
    private string m_IniFileName = "";
    public string IniFileName
    {
        get { return m_IniFileName; }
        set { m_IniFileName = value; }
    }

    private string m_IniFileSection;
    public string IniFileSection
    {
        get { return m_IniFileSection; }
        set { m_IniFileSection = value; }
    }

    private bool Initializing;

    public event EventHandler Disposed;

    public void BeginInit()
    {
        Initializing = true;
    }

    public void EndInit()
    {
        if (!this.DesignMode)
        {
            if (!string.IsNullOrEmpty(m_IniFileName))
            {
                try
                {
                    Utilities.SetPropertiesByIniFile(this, m_IniFileName, m_IniFileSection);
                }
                catch (Exception ex)
                {
                    System.Windows.Forms.MessageBox.Show("INI File - " + ex.Message);
                }
            }
        }
        Initializing = false;
    }
    #endregion
}