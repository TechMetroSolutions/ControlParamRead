﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PLCCommunication.Classes
{
    class clsCommon
    {
        public FrmLogin objFrmLogin = new FrmLogin();
        public frmMain objFrmMain =new frmMain();
        public clsIniFiles objReadWriteConfig;
        public List<string> strlstDevIPAddress = new List<string>();
        public List<string> strlstDevID = new List<string>();
        public List<string> strCustomerName = new List<string>();
        public bool blnStartDAQ = false;
        public string[] strarrParamValues;
        public string strBasicURL = string.Empty;
        public string strDeviceIDConst = "&deviceID=";
        public string strCreateDeviceURL = "createdevice?dbName=";
        public string strAddDataURL = "addfeaturedata?dbName=";
        public string strDeviceActivityURL = "addactivitydata?dbName=";
        public string strAddAlarmURL = "addalarmdata?dbName=";
        public string strAddProdDataURL = "addproductiondata?dbName=";
        public string strUpdateFeatureDataURL = "updatenameunit?dbName=";
        public string fngetTimeSpan()
        {
            // epoch timestamp.
            TimeSpan t = DateTime.UtcNow - new DateTime(1970, 1, 1);
            int secondsSinceEpoch = (int)t.TotalSeconds;

            return secondsSinceEpoch.ToString() + ".00";
        }


    }
}
