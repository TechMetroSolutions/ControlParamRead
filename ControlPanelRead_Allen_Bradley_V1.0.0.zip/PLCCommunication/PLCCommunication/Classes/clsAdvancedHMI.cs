﻿using AdvancedHMIDrivers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLCCommunication.Classes
{
    class clsAdvancedHMI
    {
        EthernetIPforSLCMicroComm MyMicroLogix = new EthernetIPforSLCMicroComm();
        public string strURLToExecure = string.Empty;
        public List<string> strparamTags = new List<string>();
        public string DeviceId = string.Empty;
        public string CustomerName = string.Empty;
        public string postData;
        public int index = 001;
        public byte[] data;
        public bool fnConnectToDevice(string strIPAddress)
        {
            Logger.Info("Entering into fnConnectToDevice()");
            try
            {
                MyMicroLogix.IPAddress = strIPAddress;
                Logger.Info("Exiting into fnConnectToDevice()");
                return true;

            }
            catch (Exception ex)
            {
                Logger.Error("fnConnectToDevice()" + ex.Message);
                return false;
            }
        }

        public void fnGetparamList(string DeviceID)
        {
            Logger.Info("Entering into fnReadParameterConfig()");
            try
            {
                clsIniFiles ini = new clsIniFiles(Application.StartupPath + "\\ParameterConfig.ini");
                int int_ParaConfig_SaveIndex = Convert.ToInt32(ini.IniReadValue("Parameter Count", "Total Count"));
                strparamTags.Clear();
                for (int i = 1; i <= int_ParaConfig_SaveIndex; i++)
                {
                    if (DeviceID == (ini.IniReadValue("Parameter" + " " + i, "Device Id")))
                    {

                        strparamTags.Add(ini.IniReadValue("Parameter" + " " + i, "Parameter Tag"));

                    }
                }

                clsIniFiles inii = new clsIniFiles(Application.StartupPath + "\\CreateDeviceConfig.ini");
                int int_CreateDeviceSaveIndex = Convert.ToInt32(inii.IniReadValue("Device Count", "Total Count"));
                for (int i = 1; i <= int_CreateDeviceSaveIndex; i++)
                {
                    if (DeviceID == (inii.IniReadValue("Device" + " " + i, "Device Id")))
                    {
                        DeviceId = DeviceID;
                        CustomerName = inii.IniReadValue("Device" + " " + i, "Customer Name");
                    }
                }

                Thread thr1 = new Thread(new ThreadStart(fnReadParams));
                thr1.Start();
            }
            catch (Exception ex)
            {
                Logger.Error("fnReadParameterConfig()" + ex.Message);
            }
            Logger.Info("Exiting into fnReadParameterConfig()");
        }

        private string[] fnGetparameterData()
        {
            Logger.Info("Entering into fnGetparameterData()");
            int iLen = strparamTags.Count;
            string[] strarrOutParamData = new string[iLen];
            try
            {
                try
                {
                    for (int i = 0; i < iLen; i++)
                    {
                        strarrOutParamData[i] = "aa"; //MyMicroLogix.ReadAny(strparamTags[i]);//"aa";
                    }
                }
                catch (Exception ec)
                {
                    MessageBox.Show("Invalid tag name added.");
                    Logger.Error("fnConnectToDevice()" + ec.Message);
                }
            }
            catch (Exception ex)
            {
                Logger.Error("fnGetparameterData()" + ex.Message);
            }

            Logger.Info("Exiting into fnGetparameterData()");
            return strarrOutParamData;
        }

        private void fnAddData()
        {
            Logger.Info("Entering into fnAddData()");
            try
            {
                Program.objAdvanceHMI.strURLToExecure = Program.objclsComm.strBasicURL + Program.objclsComm.strAddDataURL + CustomerName + " & deviceID = " + DeviceId;
                Program.objAdvanceHMI.postData = "[";
                for (int i = 0; i < strparamTags.Count; i++)
                {
                    // string data = strparamTags[i] + "," + Program.objclsComm.strarrParamValues[i];
                    Program.objAdvanceHMI.postData += string.Format("{0:000}", index) + "," + Program.objclsComm.strarrParamValues[i]+",";
                    index++;
                }
                string date = Program.objclsComm.fngetTimeSpan();
                Program.objAdvanceHMI.postData += date;
                Program.objAdvanceHMI.postData += "]";
                Program.objAdvanceHMI.data = Encoding.ASCII.GetBytes(Program.objAdvanceHMI.postData);
                // fnSendDatawithURL();
            }
            catch (Exception ex)
            {
                Logger.Error("fnAddData()" + ex.Message);
            }
            Logger.Info("Exiting into fnAddData()");
        }
        private void fnReadParams()
        {
            while (Program.objclsComm.blnStartDAQ)
            {
                Program.objclsComm.strarrParamValues = fnGetparameterData();
                fnAddData();
                Thread.Sleep(10);
            }
        }

        public void fnExecuteURL()
        {
            Logger.Info("Entering into fnExecuteURL()");
            try
            {
                //   string strSMSGatewayLink = strLink;
                Thread.Sleep(10);
                // creating web request to send sms
                HttpWebRequest _createRequest = (HttpWebRequest)WebRequest.Create(strURLToExecure);
                // getting response of sms
                HttpWebResponse myResp = (HttpWebResponse)_createRequest.GetResponse();
                System.IO.StreamReader _responseStreamReader = new System.IO.StreamReader(myResp.GetResponseStream());
                string responseString = _responseStreamReader.ReadToEnd();

                _responseStreamReader.Close();
                myResp.Close();
            }
            catch (Exception ce)
            {
                MessageBox.Show("Info Not Sent! Exception " + ce.ToString());
                Logger.Error("fnExecuteURL()" + ce.Message);
            }
            Logger.Info("Exiting into fnExecuteURL()");
        }

        public void fnSendDatawithURL()
        {
            Logger.Info("Entering into fnSendDatawithURL()");
            try
            {
                Thread.Sleep(10);
                // creating web request to send sms
                HttpWebRequest _createRequest = (HttpWebRequest)WebRequest.Create(strURLToExecure);
                // getting response of sms

                _createRequest.Method = "POST";
                _createRequest.ContentType = "text/plain;charset=UTF-8";
                _createRequest.ContentLength = data.Length;

                using (var stream = _createRequest.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }
                HttpWebResponse myResp = (HttpWebResponse)_createRequest.GetResponse();
                System.IO.StreamReader _responseStreamReader = new System.IO.StreamReader(myResp.GetResponseStream());
                string responseString = _responseStreamReader.ReadToEnd();

                _responseStreamReader.Close();
                myResp.Close();
            }
            catch (Exception ce)
            {
                Logger.Error("fnSendDatawithURL()" + ce.Message);
                MessageBox.Show("Info Not Sent! Exception " + ce.ToString());
            }
            Logger.Info("Exiting into fnSendDatawithURL()");
        }
    }
}
