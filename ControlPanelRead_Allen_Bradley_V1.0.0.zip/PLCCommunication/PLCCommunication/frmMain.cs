﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.ServiceProcess;

namespace PLCCommunication
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        #region Create Device

        bool blnCreateDeviceIsEdit = false;
        int int_CreateDevice_rowIndex;
        int int_CreateDeviceSaveIndex = 1;
        string str_IniFileCreateDeviceSectionName;
        string[] SectionCreateDeviceList = new string[20];
        private void btnCreateDevice_Click(object sender, EventArgs e)
        {

            Logger.Info("Entering into btnCreateDevice_Click()");
            try
            {
                // strSMSGatewayLink = "https://infinite-uptime-1232.appspot.com/extapi/createdevice?dbName=" + txtCustomerName.Text + "&deviceID=" + txtDeviceId.Text + "&deviceName=" + txtDeviceName.Text + "&machineName=" + txtMachineName.Text;
                for (int i = 0; i < GridViewCreateDevice.Rows.Count; i++)
                {
                    Program.objAdvanceHMI.strURLToExecure = Program.objclsComm.strBasicURL + Program.objclsComm.strCreateDeviceURL + GridViewCreateDevice.Rows[i].Cells[5].Value + Program.objclsComm.strDeviceIDConst + GridViewCreateDevice.Rows[i].Cells[6].Value + "&deviceName=" + GridViewCreateDevice.Rows[i].Cells[7].Value + "&machineName=" + GridViewCreateDevice.Rows[i].Cells[8].Value;
                    Program.objAdvanceHMI.fnExecuteURL();
                }

            }
            catch (Exception ex)
            {
                Logger.Error("btnCreateDevice_Click()" + ex.Message);
            }
            Logger.Info("Exiting into btnCreateDevice_Click()");
        }
        private void btnCreateDeviceAdd_Click(object sender, EventArgs e)
        {
            Logger.Info("Entering into btnCreateDeviceAdd_Click()");
            try
            {
                if (cmbControlMake.Text == "")
                {
                    MessageBox.Show("Select Controler Make..!!");
                    cmbControlMake.Focus();
                }
                else if (cmbControlModel.Text == "")
                {
                    MessageBox.Show("Select Controler Model..!!");
                    cmbControlModel.Focus();
                }
                else if (txtIPAddress.Text == "")
                {
                    MessageBox.Show("Enter IP Address..!!");
                    txtIPAddress.Focus();
                }
                else if (txtPortNo.Text == "")
                {
                    MessageBox.Show("Enter Port No..!!");
                    txtPortNo.Focus();
                }
                else if (txtDeviceId.Text == "")
                {
                    MessageBox.Show("Enter Device Id..!!");
                    txtDeviceId.Focus();
                }
                else if (txtMachineName.Text == "")
                {
                    MessageBox.Show("Enter Machine Name..!!");
                    txtMachineName.Focus();
                }
                else if (txtDeviceName.Text == "")
                {
                    MessageBox.Show("Enter Device Name..!!");
                    txtDeviceName.Focus();
                }
                else
                {
                    //if (!blnCreateDeviceIsEdit)
                    //{
                    //    int_CreateDeviceSaveIndex++;
                    //}
                    //GridViewCreateDevice.Rows.Add(cmbControlMake.Text, cmbControlModel.Text, txtIPAddress.Text, txtPortNo.Text, txtCustomerName.Text, txtDeviceId.Text, txtMachineName.Text);
                    GridViewCreateDevice.Rows.Clear();
                    fnWriteCreateDevice();
                    fnReadIniFileSectionOfCreateDevice();
                    fnReadDeviceIdFromFile();
                    fnClearCreateDeviceControls();
                    fnReadCreateDevice();
                    btnCreateDeviceAdd.Text = "Add";
                }
            }
            catch (Exception ex)
            {
                Logger.Error("btnCreateDeviceAdd_Click()" + ex.Message);
            }
            Logger.Info("Exiting into btnCreateDeviceAdd_Click()");

        }
        private void btnCreateDeviceEdit_Click(object sender, EventArgs e)
        {
            Logger.Info("Entering into btnCreateDeviceEdit_Click()");
            try
            {
                blnCreateDeviceIsEdit = true;
                cmbControlMake.Text = GridViewCreateDevice.Rows[int_CreateDevice_rowIndex].Cells[1].Value.ToString();
                cmbControlModel.Text = GridViewCreateDevice.Rows[int_CreateDevice_rowIndex].Cells[2].Value.ToString();
                txtIPAddress.Text = GridViewCreateDevice.Rows[int_CreateDevice_rowIndex].Cells[3].Value.ToString();
                txtPortNo.Text = GridViewCreateDevice.Rows[int_CreateDevice_rowIndex].Cells[4].Value.ToString();
                txtCustomerName.Text = GridViewCreateDevice.Rows[int_CreateDevice_rowIndex].Cells[5].Value.ToString();
                txtDeviceId.Text = GridViewCreateDevice.Rows[int_CreateDevice_rowIndex].Cells[6].Value.ToString();
                txtDeviceName.Text = GridViewCreateDevice.Rows[int_CreateDevice_rowIndex].Cells[7].Value.ToString();
                txtMachineName.Text = GridViewCreateDevice.Rows[int_CreateDevice_rowIndex].Cells[8].Value.ToString();
                txtParameterCount.Text = GridViewCreateDevice.Rows[int_CreateDevice_rowIndex].Cells[9].Value.ToString();
                // int_CreateDevice_CurrentTotalFileCount = int_CreateDeviceSaveIndex;
                // int_CreateDevice_CurrentTotalFileCount--;
                // int_CreateDeviceSaveIndex = str_IniFileSectionName;
                GridViewCreateDevice.Rows.RemoveAt(int_CreateDevice_rowIndex);
                blnCreateDeviceIsEdit = true;
                btnCreateDeviceAdd.Text = "Save";
                btnCreateDeviceEdit.Enabled = false;
                btnRemoveDevice.Enabled = false;
            }
            catch (Exception ex)
            {
                Logger.Error("btnCreateDeviceEdit_Click()" + ex.Message);
            }
            Logger.Info("Exiting into btnCreateDeviceEdit_Click()");
        }
        private void btnCreateDeviceRemove_Click(object sender, EventArgs e)
        {
            Logger.Info("Entering into btnCreateDeviceRemove_Click()");
            try
            {
                #region Old Code
                ////WritePrivateProfileString("Device" + " " + int_DeviceFileIndex, null, null, Application.StartupPath + "\\CreateDeviceConfig.ini");
                ////clsIniFiles ini = new clsIniFiles(Application.StartupPath + "\\CreateDeviceConfig.ini");
                ////int fileTotalCount = Convert.ToInt32(ini.IniReadValue("Device Count", "Total Count"));
                ////fileTotalCount--;
                ////ini.IniWriteValue("Device Count", "Total Count", Convert.ToString(fileTotalCount));
                //GridViewCreateDevice.Rows.RemoveAt(int_CreateDevice_rowIndex);
                //GridViewCreateDevice.Refresh();

                //clsIniFiles ini = new clsIniFiles(Application.StartupPath + "\\CreateDeviceConfig.ini");
                //int fileTotalCount = Convert.ToInt32(ini.IniReadValue("Device Count", "Total Count"));
                //for (int i = 1; i <= fileTotalCount; i++)
                //{
                //   // WritePrivateProfileString("Device" + " " + i, null, null, Application.StartupPath + "\\CreateDeviceConfig.ini");
                //}

                //int j = 1;
                //for (int i = 0; i < GridViewCreateDevice.Rows.Count; i++)
                //{
                //    ini.IniWriteValue("Device Count", "Total Count", Convert.ToString(j));
                //    ini.IniWriteValue("Device" + " " + j, "Device Index", Convert.ToString(j));
                //    ini.IniWriteValue("Device" + " " + j, "Make", GridViewCreateDevice.Rows[i].Cells[1].Value.ToString());
                //    ini.IniWriteValue("Device" + " " + j, "Model", GridViewCreateDevice.Rows[i].Cells[2].Value.ToString());
                //    ini.IniWriteValue("Device" + " " + j, "IP Address", GridViewCreateDevice.Rows[i].Cells[3].Value.ToString());
                //    ini.IniWriteValue("Device" + " " + j, "Port No", GridViewCreateDevice.Rows[i].Cells[4].Value.ToString());
                //    //  ini.IniWriteValue("Device" + " " + j, "Customer Name",GridViewCreateDevice.Rows[i].Cells[1].Value.ToString());
                //    ini.IniWriteValue("Device" + " " + j, "Device Id", GridViewCreateDevice.Rows[i].Cells[6].Value.ToString());
                //    ini.IniWriteValue("Device" + " " + j, "Device Name", GridViewCreateDevice.Rows[i].Cells[7].Value.ToString());
                //    ini.IniWriteValue("Device" + " " + j, "Machine Name", GridViewCreateDevice.Rows[i].Cells[8].Value.ToString());
                //    ini.IniWriteValue("Device" + " " + j, "Parameter Count", GridViewCreateDevice.Rows[i].Cells[9].Value.ToString());
                //    j++;
                //}
                #endregion

                clsIniFiles ini = new clsIniFiles(Application.StartupPath + "\\CreateDeviceConfig.ini");
                ini.IniDeleteSections(str_IniFileCreateDeviceSectionName, null, null);
                GridViewCreateDevice.Rows.RemoveAt(int_CreateDevice_rowIndex);
                GridViewCreateDevice.Refresh();
                fnReadDeviceIdFromFile();
                btnCreateDeviceEdit.Enabled = false;
                btnRemoveDevice.Enabled = false;

            }
            catch (Exception ex)
            {
                Logger.Error("btnCreateDeviceRemove_Click()" + ex.Message);
            }
            Logger.Info("Exiting into btnCreateDeviceRemove_Click()");
        }
        private void GridViewCreateDevice_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Logger.Info("Entering into GridViewCreateDevice_CellClick()");
            try
            {
                int_CreateDevice_rowIndex = e.RowIndex;
                str_IniFileCreateDeviceSectionName = Convert.ToString(GridViewCreateDevice.Rows[int_CreateDevice_rowIndex].Cells[0].Value);
                btnCreateDeviceEdit.Enabled = true;
                btnRemoveDevice.Enabled = true;
            }
            catch (Exception ex)
            {
                Logger.Error("GridViewCreateDevice_CellClick()" + ex.Message);
            }
            Logger.Info("Exiting into GridViewCreateDevice_CellClick()");
        }
        private void cmbControlMake_SelectedIndexChanged(object sender, EventArgs e)
        {
            Logger.Info("Entering into cmbControlMake_SelectedIndexChanged()");
            try
            {
                if (!blnCreateDeviceIsEdit)
                {
                    fnReadCreateDevice();
                }
            }
            catch (Exception ex)
            {
                Logger.Error("cmbControlMake_SelectedIndexChanged()" + ex.Message);
            }
            Logger.Info("Exiting into cmbControlMake_SelectedIndexChanged()");
        }
        private void fnClearCreateDeviceControls()
        {
            Logger.Info("Entering into fnClearCreateDeviceControls()");
            try
            {
                cmbControlMake.ResetText();
                cmbControlModel.ResetText();
                txtIPAddress.ResetText();
                txtPortNo.ResetText();
                txtCustomerNameCreateDevice.ResetText();
                txtDeviceName.ResetText();
                txtDeviceId.ResetText();
                txtMachineName.ResetText();
                txtParameterCount.ResetText();
            }
            catch (Exception ex)
            {
                Logger.Error("fnClearCreateDeviceControls()" + ex.Message);
            }
            Logger.Info("Exiting into fnClearCreateDeviceControls()");
        }
        private void fnWriteCreateDevice()
        {
            Logger.Info("Entering into fnWriteCreateDevice()");
            try
            {
                clsIniFiles ini = new clsIniFiles(Application.StartupPath + "\\CreateDeviceConfig.ini");
                if (!blnCreateDeviceIsEdit)
                {
                    ini.IniWriteValue("Device" + " " + int_CreateDeviceSaveIndex, "Make", cmbControlMake.Text);
                    ini.IniWriteValue("Device" + " " + int_CreateDeviceSaveIndex, "Model", cmbControlModel.Text);
                    ini.IniWriteValue("Device" + " " + int_CreateDeviceSaveIndex, "IP Address", txtIPAddress.Text);
                    ini.IniWriteValue("Device" + " " + int_CreateDeviceSaveIndex, "Port No", txtPortNo.Text);
                    ini.IniWriteValue("Device" + " " + int_CreateDeviceSaveIndex, "Device Id", txtDeviceId.Text);
                    ini.IniWriteValue("Device" + " " + int_CreateDeviceSaveIndex, "Device Name", txtDeviceName.Text);
                    ini.IniWriteValue("Device" + " " + int_CreateDeviceSaveIndex, "Machine Name", txtMachineName.Text);
                    ini.IniWriteValue("Device" + " " + int_CreateDeviceSaveIndex, "Parameter Count", txtParameterCount.Text);

                }
                else
                {
                    blnCreateDeviceIsEdit = false;
                    //  ini.IniWriteValue("Device Count", "Total Count", Convert.ToString(int_CreateDeviceSaveIndex));
                    //  ini.IniWriteValue(str_IniFileSectionName, "Device Index", Convert.ToString(int_CreateDeviceSaveIndex));
                    ini.IniWriteValue(str_IniFileCreateDeviceSectionName, "Make", cmbControlMake.Text);
                    ini.IniWriteValue(str_IniFileCreateDeviceSectionName, "Model", cmbControlModel.Text);
                    ini.IniWriteValue(str_IniFileCreateDeviceSectionName, "IP Address", txtIPAddress.Text);
                    ini.IniWriteValue(str_IniFileCreateDeviceSectionName, "Port No", txtPortNo.Text);
                    //ini.IniWriteValue(str_IniFileSectionName, "Customer Name", txtCustomerName.Text);
                    ini.IniWriteValue(str_IniFileCreateDeviceSectionName, "Device Id", txtDeviceId.Text);
                    ini.IniWriteValue(str_IniFileCreateDeviceSectionName, "Device Name", txtDeviceName.Text);
                    ini.IniWriteValue(str_IniFileCreateDeviceSectionName, "Machine Name", txtMachineName.Text);
                    ini.IniWriteValue(str_IniFileCreateDeviceSectionName, "Parameter Count", txtParameterCount.Text);
                }
            }
            catch (Exception ex)
            {
                Logger.Error("fnWriteCreateDevice()" + ex.Message);
            }
            Logger.Info("Exiting into fnWriteCreateDevice()");
        }
        private void fnReadCreateDevice()
        {
            Logger.Info("Entering into fnReadCreateDevice()");
            try
            {
                clsIniFiles ini = new clsIniFiles(Application.StartupPath + "\\CreateDeviceConfig.ini");
                clsIniFiles inii = new clsIniFiles(Application.StartupPath + "\\CommanSettingConfig.ini");
                //int_CreateDeviceSaveIndex = Convert.ToInt32(ini.IniReadValue("Device Count", "Total Count"));
                GridViewCreateDevice.Rows.Clear();
                if (blnFirstTimeReadData)
                {
                    txtCustomerNameCreateDevice.Text = inii.IniReadValue("CommanSetting", "Customer Name");
                    Program.objclsComm.strlstDevIPAddress.Clear();
                    Program.objclsComm.strlstDevID.Clear();
                    // Program.objclsComm.strCustomerName.Clear();

                    for (int i = 0; i < SectionCreateDeviceList.Length; i++)
                    {
                        GridViewCreateDevice.Rows.Add(SectionCreateDeviceList[i], ini.IniReadValue(SectionCreateDeviceList[i], "Make"), ini.IniReadValue(SectionCreateDeviceList[i], "Model"), ini.IniReadValue(SectionCreateDeviceList[i], "IP Address"), ini.IniReadValue(SectionCreateDeviceList[i], "Port No"), inii.IniReadValue("CommanSetting", "Customer Name"), ini.IniReadValue(SectionCreateDeviceList[i], "Device Id"), ini.IniReadValue(SectionCreateDeviceList[i], "Device Name"), ini.IniReadValue(SectionCreateDeviceList[i], "Machine Name"), ini.IniReadValue(SectionCreateDeviceList[i], "Parameter Count"));
                        Program.objclsComm.strlstDevIPAddress.Add(ini.IniReadValue(SectionCreateDeviceList[i], "IP Address"));
                        Program.objclsComm.strlstDevID.Add(ini.IniReadValue(SectionCreateDeviceList[i], "Device Id"));
                        //Program.objclsComm.strCustomerName.Add(ini.IniReadValue("Device" + " " + i, "Customer Name"));
                    }
                }
                else
                {
                    txtCustomerNameCreateDevice.Text = inii.IniReadValue("CommanSetting", "Customer Name");

                    for (int i = 0; i < SectionCreateDeviceList.Length; i++)
                    {
                        if (cmbControlMake.Text == ini.IniReadValue(SectionCreateDeviceList[i], "Make"))
                        {
                            GridViewCreateDevice.Rows.Add(SectionCreateDeviceList[i], ini.IniReadValue(SectionCreateDeviceList[i], "Make"), ini.IniReadValue(SectionCreateDeviceList[i], "Model"), ini.IniReadValue(SectionCreateDeviceList[i], "IP Address"), ini.IniReadValue(SectionCreateDeviceList[i], "Port No"), inii.IniReadValue("CommanSetting", "Customer Name"), ini.IniReadValue(SectionCreateDeviceList[i], "Device Id"), ini.IniReadValue(SectionCreateDeviceList[i], "Device Name"), ini.IniReadValue(SectionCreateDeviceList[i], "Machine Name"), ini.IniReadValue(SectionCreateDeviceList[i], "Parameter Count"));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error("fnReadCreateDevice()" + ex.Message);
            }
            Logger.Info("Exiting into fnReadCreateDevice()");
        }
        private void fnReadIniFileSectionOfCreateDevice()
        {

            Array.Clear(SectionCreateDeviceList, 0, SectionCreateDeviceList.Length);

            clsIniFiles ini = new clsIniFiles(Application.StartupPath + "\\CreateDeviceConfig.ini");
            SectionCreateDeviceList = ini.GetIniSectionNames();

            string LastSectionNo = SectionCreateDeviceList[SectionCreateDeviceList.Length - 1];
            //string[] parts = LastSectionNo.Split(' ');
            int index = Convert.ToInt32(LastSectionNo.Split(' ')[1]);// Convert.ToInt32(parts[1]);
            int_CreateDeviceSaveIndex = index + 1;
        }

        #endregion

        #region Parameter Configuration

        List<string> lstNoOFDeviceIdInFile = new List<string>();
        int int_NoOfParaCountPerDevice;
        bool blnParameterConfigIsEdit = false;
        int int_ParaConfig_rowIndex;
        int int_ParaConfig_SaveIndex = 1;
        //int int_ParaConfig_FileIndex;
        //int int_paraConfig_CurrentTotalFileCount;
        bool blnFirstTimeReadData = true;
        string str_IniFileParaConfigSectionName;
        string[] SectionParaConfigList = new string[100];
        private void btnUpdateFeature_Click(object sender, EventArgs e)
        {
            Logger.Info("Entering into btnUpdateFeature_Click()");
            try
            {
                #region trial
                //  strSMSGatewayLink = "https://infinite-uptime-1232.appspot.com/extapi/updatenameunit?dbName=" + txtCustomerName.Text + "&deviceID=" + txtDeviceId.Text;

                //   postData = "[{\"id\": 1, \"name\": \"VX\", \"unit\": \"mm/s\"},{\"id\": 2, \"name\": \"VY\", \"unit\": \"mm/s\"}]";
                //   data = Encoding.ASCII.GetBytes(postData);
                //List<string> strArr = new List<string>();
                //for (int i = 0; i < cmbDeviceId.Items.Count; i++)
                //{
                //    if(!strArr.Contains(cmbDeviceId.Items[i].ToString()))
                //    {
                //        strArr.Add(cmbDeviceId.Items[i].ToString());
                //    }
                //}

                //  int[,] strDataArray = new int[GridViewParameterConfig.Rows.Count, 20];
                #endregion
               
                int iCnt = 0;
                for (int i = 0; i < cmbDeviceId.Items.Count; i++)
                {
                    Program.objAdvanceHMI.strURLToExecure = Program.objclsComm.strBasicURL + Program.objclsComm.strUpdateFeatureDataURL + GridViewCreateDevice.Rows[i].Cells[5].Value + Program.objclsComm.strDeviceIDConst + GridViewCreateDevice.Rows[i].Cells[6].Value + "&deviceName=" + GridViewCreateDevice.Rows[i].Cells[7].Value + "&machineName=" + GridViewCreateDevice.Rows[i].Cells[8].Value;
                    iCnt = 0;
                    Program.objAdvanceHMI.postData = "[{";
                    for (int j = 0; j < GridViewParameterConfig.Rows.Count; j++)
                    {
                        if (cmbDeviceId.Items[i].ToString() == GridViewParameterConfig.Rows[j].Cells[1].Value.ToString())
                        {
                            if (j != 0)
                            {
                                Program.objAdvanceHMI.postData += ",{";
                            }
                            Program.objAdvanceHMI.postData += "\"id\":" + (iCnt + 1) + ",\"name\":\"" + GridViewParameterConfig.Rows[j].Cells[3].Value.ToString() + "\", \"unit\":\"" + GridViewParameterConfig.Rows[j].Cells[4].Value.ToString() + "\"}";
                            iCnt++;
                        }
                    }
                    Program.objAdvanceHMI.postData += "]";
                 //   "[{\"id\": 1, \"name\": \"VX\", \"unit\": \"mm/s\"},{\"id\": 2, \"name\": \"VY\", \"unit\": \"mm/s\"}]";
                    Program.objAdvanceHMI.data = Encoding.ASCII.GetBytes(Program.objAdvanceHMI.postData);
                     Program.objAdvanceHMI.fnSendDatawithURL();
                }
            }
            catch (Exception ex)
            {
                Logger.Error("btnUpdateFeature_Click()" + ex.Message);
            }
            Logger.Info("Exiting into btnUpdateFeature_Click()");
        }

        private void btnAddParameters_Click(object sender, EventArgs e)
        {
            Logger.Info("Entering into btnAddParameters_Click()");
            try
            {

                if (File.Exists(Application.StartupPath + "\\ParameterConfig.ini"))
                {
                    fnCheckParameterCount();
                }
                if ((int_NoOfParaCountPerDevice != lstNoOFDeviceIdInFile.Count) || btnAddParameters.Text == "Save")
                {
                    if (cmbDeviceId.Text == "")
                    {
                        MessageBox.Show("Select Device Id..!!");
                        cmbDeviceId.Focus();
                    }
                    //else if (txtParaConfigMachineName.Text == "")
                    //{
                    //    MessageBox.Show("Enter Machine Name..!!");
                    //    txtParaConfigMachineName.Focus();
                    //}
                    else if (txtParameterName.Text == "")
                    {
                        MessageBox.Show("Enter Parameter Name..!!");
                        txtParameterName.Focus();
                    }
                    else if (txtParameterUnit.Text == "")
                    {
                        MessageBox.Show("Enter Parameter Unit..!!");
                        txtParameterUnit.Focus();
                    }
                    else if (txtParameterTag.Text == "")
                    {
                        MessageBox.Show("Enter Parameter Tag..!!");
                        txtParameterTag.Focus();
                    }
                    else
                    {
                        //if (!blnParameterConfigIsEdit)
                        //{
                        //    int_ParaConfig_SaveIndex++;
                        //}
                        //GridViewParameterConfig.Rows.Add(txtParameterName.Text, txtParameterUnit.Text, txtParameterTag.Text);
                        GridViewParameterConfig.Rows.Clear();
                        fnWriteParameterConfig();
                        fnReadIniFileSectionOfParaConfig();
                        fnCleareParamerteConfigControls();
                        fnReadParameterConfig();
                        //int_ParaConfig_SaveIndex++;
                        btnAddParameters.Text = "Add";
                    }
                }
                else
                {
                    MessageBox.Show("Parameter Count Exceed limit ");
                }
            }
            catch (Exception ex)
            {
                Logger.Error("btnAddParameters_Click()" + ex.Message);
            }
            Logger.Info("Exiting into btnAddParameters_Click()");
        }
        private void btnEdit_Click(object sender, EventArgs e)
        {
            Logger.Info("Entering into btnEdit_Click()");
            try
            {
            
                blnParameterConfigIsEdit = true;
                cmbDeviceId.Text = GridViewParameterConfig.Rows[int_ParaConfig_rowIndex].Cells[1].Value.ToString();
                txtParaConfigMachineName.Text = GridViewParameterConfig.Rows[int_ParaConfig_rowIndex].Cells[2].Value.ToString();
                txtParameterName.Text = GridViewParameterConfig.Rows[int_ParaConfig_rowIndex].Cells[3].Value.ToString();
                txtParameterUnit.Text = GridViewParameterConfig.Rows[int_ParaConfig_rowIndex].Cells[4].Value.ToString();
                txtParameterTag.Text = GridViewParameterConfig.Rows[int_ParaConfig_rowIndex].Cells[5].Value.ToString();
                // int_paraConfig_CurrentTotalFileCount = int_ParaConfig_SaveIndex;
                // int_paraConfig_CurrentTotalFileCount--;
                // int_ParaConfig_SaveIndex = int_ParaConfig_FileIndex;
                GridViewParameterConfig.Rows.RemoveAt(int_ParaConfig_rowIndex);
                btnAddParameters.Text = "Save";

                btnEdit.Enabled = false;
                btnRemoveParameter.Enabled = false;
            }
            catch (Exception ex)
            {
                Logger.Error("btnEdit_Click()" + ex.Message);
            }
            Logger.Info("Exiting into btnEdit_Click()");

        }
        private void btnRemove_Click(object sender, EventArgs e)
        {
            Logger.Info("Entering into btnRemove_Click()");
            try
            {
                #region Old Data
                ////WritePrivateProfileString("Parameter" + " " + int_ParaConfig_FileIndex, null, null, Application.StartupPath + "\\ParameterConfig.ini");
                ////clsIniFiles ini = new clsIniFiles(Application.StartupPath + "\\ParameterConfig.ini");
                ////int fileTotalCount = Convert.ToInt32(ini.IniReadValue("Parameter Count", "Total Count"));
                ////fileTotalCount--;
                ////ini.IniWriteValue("Parameter Count", "Total Count", Convert.ToString(fileTotalCount));
                //GridViewParameterConfig.Rows.RemoveAt(int_ParaConfig_rowIndex);
                //GridViewParameterConfig.Refresh();

                //clsIniFiles ini = new clsIniFiles(Application.StartupPath + "\\ParameterConfig.ini");
                //int fileTotalCount = Convert.ToInt32(ini.IniReadValue("Parameter Count", "Total Count"));
                //for (int i = 1; i <= fileTotalCount; i++)
                //{
                //    //WritePrivateProfileString("Parameter" + " " + i, null, null, Application.StartupPath + "\\ParameterConfig.ini");
                //}

                //int j = 1;
                //for (int i = 0; i < GridViewParameterConfig.Rows.Count; i++)
                //{

                //    ini.IniWriteValue("Parameter Count", "Total Count", Convert.ToString(j));
                //    ini.IniWriteValue("Parameter" + " " + j, "Parameter Index", Convert.ToString(j));
                //    ini.IniWriteValue("Parameter" + " " + j, "Device Id", GridViewParameterConfig.Rows[i].Cells[1].Value.ToString());
                //    ini.IniWriteValue("Parameter" + " " + j, "Machine Name", GridViewParameterConfig.Rows[i].Cells[2].Value.ToString());
                //    ini.IniWriteValue("Parameter" + " " + j, "Parameter Name", GridViewParameterConfig.Rows[i].Cells[3].Value.ToString());
                //    ini.IniWriteValue("Parameter" + " " + j, "Parameter Unit", GridViewParameterConfig.Rows[i].Cells[4].Value.ToString());
                //    ini.IniWriteValue("Parameter" + " " + j, "Parameter Tag", GridViewParameterConfig.Rows[i].Cells[5].Value.ToString());
                //    j++;
                //}
                //btnEdit.Enabled = false;
                //btnRemove.Enabled = false;
                #endregion

                clsIniFiles ini = new clsIniFiles(Application.StartupPath + "\\ParameterConfig.ini");
                ini.IniDeleteSections(str_IniFileParaConfigSectionName, null, null);
                GridViewParameterConfig.Rows.RemoveAt(int_ParaConfig_rowIndex);
                GridViewParameterConfig.Refresh();
                btnEdit.Enabled = false;
                btnRemoveParameter.Enabled = false;
            }
            catch (Exception ex)
            {
                Logger.Error("btnRemove_Click()" + ex.Message);
            }
            Logger.Info("Exiting into btnRemove_Click()");
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Logger.Info("Entering into dataGridView1_CellClick()");
            try
            {
                int_ParaConfig_rowIndex = e.RowIndex;
                str_IniFileParaConfigSectionName = Convert.ToString(GridViewParameterConfig.Rows[int_ParaConfig_rowIndex].Cells[0].Value);
                btnEdit.Enabled = true;
                btnRemoveParameter.Enabled = true;
                int_ParaConfig_SaveIndex =Convert.ToInt32(str_IniFileParaConfigSectionName.Split(' ')[1]);
            }
            catch (Exception ex)
            {
                Logger.Error("dataGridView1_CellClick()" + ex.Message);
            }
            Logger.Info("Exiting into dataGridView1_CellClick()");
        }
        private void cmbDeviceId_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!blnParameterConfigIsEdit)
            {
                clsIniFiles inii = new clsIniFiles(Application.StartupPath + "\\CreateDeviceConfig.ini");
                // int int_CreateDeviceSaveIndex = Convert.ToInt32(inii.IniReadValue("Device Count", "Total Count"));
                for (int i = 0; i < SectionCreateDeviceList.Length; i++)
                {
                    if (cmbDeviceId.Text == (inii.IniReadValue(SectionCreateDeviceList[i], "Device Id")))
                    {
                        txtParaConfigMachineName.Text = inii.IniReadValue(SectionCreateDeviceList[i], "Machine Name");
                    }
                }
                fnReadParameterConfig();
            }
        }
        private void fnCleareParamerteConfigControls()
        {
            Logger.Info("Entering into fnCleareParamerteConfigControls()");
            try
            {
                cmbDeviceId.ResetText();
                txtParameterName.ResetText();
                txtParameterUnit.ResetText();
                txtParameterTag.ResetText();
            //    txtParaConfigMachineName.ResetText();
            }
            catch (Exception ex)
            {
                Logger.Error("fnCleareParamerteConfigControls()" + ex.Message);
            }
            Logger.Info("Exiting into fnCleareParamerteConfigControls()");
        }
        private void fnReadDeviceIdFromFile()
        {
            Logger.Info("Entering into fnReadDeviceIdFromFile()");
            try
            {
                if (File.Exists(Application.StartupPath + "\\CreateDeviceConfig.ini"))
                {
                    clsIniFiles ini = new clsIniFiles(Application.StartupPath + "\\CreateDeviceConfig.ini");
                    //int TotalDeviceCount = Convert.ToInt32(ini.IniReadValue("Device Count", "Total Count"));
                    cmbDeviceId.Items.Clear();
                    for (int i = 0; i < SectionCreateDeviceList.Length; i++)
                    {
                        cmbDeviceId.Items.Add(ini.IniReadValue(SectionCreateDeviceList[i], "Device Id"));
                        //  cmbDeviceId.Items.Add(ini.IniReadValue("Device" + " " + i, "Device Name"));
                        // cmbDeviceId.ValueMember=

                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error("fnReadDeviceIdFromFile()" + ex.Message);
            }
            Logger.Info("Exiting into fnReadDeviceIdFromFile()");
        }
        private void fnWriteParameterConfig()
        {
            Logger.Info("Entering into fnWriteParameterConfig()");
            try
            {
                clsIniFiles ini = new clsIniFiles(Application.StartupPath + "\\ParameterConfig.ini");
                if (!blnParameterConfigIsEdit)
                {
                    //ini.IniWriteValue("Parameter Count", "Total Count", Convert.ToString(int_ParaConfig_SaveIndex));
                    // ini.IniWriteValue("Parameter" + " " + int_ParaConfig_SaveIndex, "Parameter Index", Convert.ToString(int_ParaConfig_SaveIndex));
                    ini.IniWriteValue("Parameter" + " " + int_ParaConfig_SaveIndex, "Device Id", cmbDeviceId.Text);
                    ini.IniWriteValue("Parameter" + " " + int_ParaConfig_SaveIndex, "Machine Name", txtParaConfigMachineName.Text);
                    ini.IniWriteValue("Parameter" + " " + int_ParaConfig_SaveIndex, "Parameter Name", txtParameterName.Text);
                    ini.IniWriteValue("Parameter" + " " + int_ParaConfig_SaveIndex, "Parameter Unit", txtParameterUnit.Text);
                    ini.IniWriteValue("Parameter" + " " + int_ParaConfig_SaveIndex, "Parameter Tag", txtParameterTag.Text);
                }
                else
                {
                    blnParameterConfigIsEdit = false;
                    //ini.IniWriteValue("Parameter Count", "Total Count", Convert.ToString(int_paraConfig_CurrentTotalFileCount));
                    // ini.IniWriteValue("Parameter" + " " + int_ParaConfig_SaveIndex, "Parameter Index", Convert.ToString(int_ParaConfig_SaveIndex));
                    ini.IniWriteValue("Parameter" + " " + int_ParaConfig_SaveIndex, "Device Id", cmbDeviceId.Text);
                    ini.IniWriteValue("Parameter" + " " + int_ParaConfig_SaveIndex, "Machine Name", txtParaConfigMachineName.Text);
                    ini.IniWriteValue("Parameter" + " " + int_ParaConfig_SaveIndex, "Parameter Name", txtParameterName.Text);
                    ini.IniWriteValue("Parameter" + " " + int_ParaConfig_SaveIndex, "Parameter Unit", txtParameterUnit.Text);
                    ini.IniWriteValue("Parameter" + " " + int_ParaConfig_SaveIndex, "Parameter Tag", txtParameterTag.Text);
                }
            }
            catch (Exception ex)
            {
                Logger.Error("fnWriteParameterConfig()" + ex.Message);
            }
            Logger.Info("Exiting into fnWriteParameterConfig()");
        }
        private void fnReadParameterConfig()
        {
            Logger.Info("Entering into fnReadParameterConfig()");
            try
            {
                clsIniFiles ini = new clsIniFiles(Application.StartupPath + "\\ParameterConfig.ini");

                // int_ParaConfig_SaveIndex = Convert.ToInt32(ini.IniReadValue("Parameter Count", "Total Count"));
                GridViewParameterConfig.Rows.Clear();
                if (blnFirstTimeReadData)
                {
                    for (int i = 0; i < SectionParaConfigList.Length; i++)
                    {
                        GridViewParameterConfig.Rows.Add(SectionParaConfigList[i], ini.IniReadValue(SectionParaConfigList[i], "Device Id"), ini.IniReadValue(SectionParaConfigList[i], "Machine Name"), ini.IniReadValue(SectionParaConfigList[i], "Parameter Name"), ini.IniReadValue(SectionParaConfigList[i], "Parameter Unit"), ini.IniReadValue(SectionParaConfigList[i], "Parameter Tag"));
                    }
                }
                else
                {
                    for (int i = 0; i < SectionParaConfigList.Length; i++)
                    {
                        if (cmbDeviceId.Text == ini.IniReadValue(SectionParaConfigList[i], "Device Id"))
                        {
                            GridViewParameterConfig.Rows.Add(SectionParaConfigList[i],ini.IniReadValue(SectionParaConfigList[i], "Device Id"), ini.IniReadValue(SectionParaConfigList[i], "Machine Name"), ini.IniReadValue(SectionParaConfigList[i], "Parameter Name"), ini.IniReadValue(SectionParaConfigList[i], "Parameter Unit"), ini.IniReadValue(SectionParaConfigList[i], "Parameter Tag"));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error("fnReadParameterConfig()" + ex.Message);
            }
            Logger.Info("Exiting into fnReadParameterConfig()");
        }
        private void fnCheckParameterCount()
        {
            clsIniFiles ini = new clsIniFiles(Application.StartupPath + "\\ParameterConfig.ini");
            //  int_ParaConfig_SaveIndex = Convert.ToInt32(ini.IniReadValue("Parameter Count", "Total Count"));
            lstNoOFDeviceIdInFile.Clear();
            for (int i = 0; i < SectionParaConfigList.Length; i++)
            {
                if (cmbDeviceId.Text == ini.IniReadValue(SectionParaConfigList[i], "Device Id"))
                {
                    lstNoOFDeviceIdInFile.Add(ini.IniReadValue(SectionParaConfigList[i], "Device Id"));
                }
            }


            clsIniFiles inii = new clsIniFiles(Application.StartupPath + "\\CreateDeviceConfig.ini");

            // int_CreateDeviceSaveIndex = Convert.ToInt32(inii.IniReadValue("Device Count", "Total Count"));
            for (int i = 0; i < SectionCreateDeviceList.Length; i++)
            {
                if (cmbDeviceId.Text == inii.IniReadValue(SectionCreateDeviceList[i], "Device Id"))
                {
                    int_NoOfParaCountPerDevice = Convert.ToInt32(inii.IniReadValue(SectionCreateDeviceList[i], "Parameter Count"));
                }
            }           
        }
        private void fnReadIniFileSectionOfParaConfig()
        {

            Array.Clear(SectionParaConfigList, 0, SectionParaConfigList.Length);

            clsIniFiles ini = new clsIniFiles(Application.StartupPath + "\\ParameterConfig.ini");
            SectionParaConfigList = ini.GetIniSectionNames();

            string LastSectionNo = SectionParaConfigList[SectionParaConfigList.Length - 1];
            //string[] parts = LastSectionNo.Split(' ');
            int index = Convert.ToInt32(LastSectionNo.Split(' ')[1]);// Convert.ToInt32(parts[1]);
            int_ParaConfig_SaveIndex = index + 1;
        }

        #endregion

        #region Comman Setting
        private void btnSaveCommanSetting_Click(object sender, EventArgs e)
        {
            Logger.Info("Entering into btnSaveCommanSetting_Click()");
            try
            {
                if (txtCustomerName.Text == "")
                {
                    MessageBox.Show("Enter Customer Name..!!");
                    txtCustomerName.Focus();
                }
                else if (txtReadFreq.Text == "")
                {
                    MessageBox.Show("Enter Read Frequency..!!");
                    txtReadFreq.Focus();
                }
                //else if (txtWriteFreq.Text == "")
                //{
                //    MessageBox.Show("Enter Write Frequency..!!");
                //    txtWriteFreq.Focus();
                //}
                else if (txtCloudURL.Text == "")
                {
                    MessageBox.Show("Enter Cloud URL..!!");
                    txtCloudURL.Focus();
                }
                else
                {
                    clsIniFiles ini = new clsIniFiles(Application.StartupPath + "\\CommanSettingConfig.ini");
                    ini.IniWriteValue("CommanSetting", "Customer Name", txtCustomerName.Text);
                    ini.IniWriteValue("CommanSetting", "Read Frequency", txtReadFreq.Text);
                    ini.IniWriteValue("CommanSetting", "Write Frequency", txtReadFreq.Text);
                    ini.IniWriteValue("CommanSetting", "Cloud URL", txtCloudURL.Text);
                    MessageBox.Show("Setting Save..!");
                    fnReadCommanSetting();
                }
            }
            catch (Exception ex)
            {
                Logger.Error("btnSaveCommanSetting_Click()" + ex.Message);
            }
            Logger.Info("Exiting into btnSaveCommanSetting_Click()");
        }
        private void fnReadCommanSetting()
        {
            Logger.Info("Entering into fnReadCommanSetting()");
            try
            {
                if (File.Exists(Application.StartupPath + "\\CommanSettingConfig.ini"))
                {
                    clsIniFiles ini = new clsIniFiles(Application.StartupPath + "\\CommanSettingConfig.ini");
                    txtCustomerName.Text = ini.IniReadValue("CommanSetting", "Customer Name");
                    txtReadFreq.Text = ini.IniReadValue("CommanSetting", "Read Frequency");
                    txtWriteFreq.Text = ini.IniReadValue("CommanSetting", "Write Frequency");
                    txtCloudURL.Text = ini.IniReadValue("CommanSetting", "Cloud URL");
                    Program.objclsComm.strBasicURL = ini.IniReadValue("CommanSetting", "Cloud URL");
                }
            }
            catch (Exception ex)
            {
                Logger.Error("fnReadCommanSetting()" + ex.Message);
            }
            Logger.Info("Exiting into fnReadCommanSetting()");
        }
        #endregion

        private void fnReadControlerNameAndModel()
        {
            Logger.Info("Entering into fnReadControlerNameAndModel()");
            try
            {
                if (File.Exists(Application.StartupPath + "\\ControlConfig.ini"))
                {
                    clsIniFiles ini = new clsIniFiles(Application.StartupPath + "\\ControlConfig.ini");
                    //ini.IniWriteValue("Controler", "Make", "Allen-Bradley");
                    //ini.IniWriteValue("Controler", "Model", "MicroLogix 1400");
                    cmbControlMake.Items.Add(ini.IniReadValue("Controler", "Make"));
                   // cmbControlMake.Items.Add(ini.IniReadValue("Controler1", "Make"));
                    cmbControlModel.Items.Add(ini.IniReadValue("Controler", "Model"));
                }
            }
            catch (Exception ex)
            {
                Logger.Error("fnReadControlerNameAndModel()" + ex.Message);
            }
            Logger.Info("Exiting into fnReadControlerNameAndModel()");

        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            Logger.Info("Entering into btnExit_Click()");
            try
            {
                DialogResult result = MessageBox.Show("Do you want to exit...!", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);

                if (result == DialogResult.Yes)
                {
                    Application.Exit();
                }
            }
            catch (Exception ex)
            {
                Logger.Error("btnExit_Click()" + ex.Message);
            }
            Logger.Info("Exiting into btnExit_Click()");
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            Logger.Info("Entering into Form1_Load()");
            try
            {
                GridViewCreateDevice.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
                GridViewParameterConfig.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
                fnReadControlerNameAndModel();
                fnReadCommanSetting();

                if (File.Exists(Application.StartupPath + "\\CreateDeviceConfig.ini"))
                {
                    fnReadIniFileSectionOfCreateDevice();
                    fnReadCreateDevice();

                }
                if (File.Exists(Application.StartupPath + "\\ParameterConfig.ini"))
                {
                    fnReadIniFileSectionOfParaConfig();
                    fnReadParameterConfig();
                    blnFirstTimeReadData = false;

                }
                fnReadDeviceIdFromFile();
            }
            catch (Exception ex)
            {
                Logger.Error("Form1_Load()" + ex.Message);
            }
            Logger.Info("Exiting into Form1_Load()");
        }
        private void btnServiceStart_Click(object sender, EventArgs e)
        {
            ServiceController service = new ServiceController("TMSPLC_COMM");
            try
            {
                TimeSpan timeout = TimeSpan.FromMilliseconds(500);

                service.Start();
                service.WaitForStatus(ServiceControllerStatus.Running, timeout);
            }
            catch(Exception ex)
            {
                Logger.Error(ex.Message);
            }
        }
        private void btnServiceStop_Click(object sender, EventArgs e)
        {
            ServiceController service = new ServiceController("TMSPLC_COMM");
            try
            {
                TimeSpan timeout = TimeSpan.FromMilliseconds(500);

                service.Stop();
                service.WaitForStatus(ServiceControllerStatus.Stopped, timeout);
            }
            catch (Exception ex)
            {
                Logger.Error(ex.Message);
            }
        }

        
    }
}
