﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLCCommunication
{
    public partial class FrmLogin : Form
    {
        #region Variables
        private string StrDate;
        public string strDate
        {
            get { return StrDate; }
            set { StrDate = value; }
        }
        private string StrOriginalCulture;
        public string strOriginalCulture
        {
            get { return StrOriginalCulture; }
            set { StrOriginalCulture = value; }
        }
        private int IWeekNo;
        public int iWeekNo
        {
            get { return IWeekNo; }
            set { IWeekNo = value; }
        }
        private int IMM;
        public int iMM
        {
            get { return IMM; }
            set { IMM = value; }
        }
        private int IDD;
        public int iDD
        {
            get { return IDD; }
            set { IDD = value; }
        }
        private int IYYYY;
        public int iYYYY
        {
            get { return IYYYY; }
            set { IYYYY = value; }
        }
        private int ICCCC;
        public int iCCCC
        {
            get { return ICCCC; }
            set { ICCCC = value; }
        }
        private bool BlnCulture;
        public bool blnCulture
        {
            get { return BlnCulture; }
            set { BlnCulture = value; }
        }
        private bool BlnContinue;
        public bool blnContinue
        {
            get { return BlnContinue; }
            set { BlnContinue = value; }
        }
        #endregion
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                Logger.Info("Entering into btnLogin_Click");
                //user Name :-3GN4s/7DLIs=
                //Pass :-uwCn8b9wgLA+WuLLfyo0Iw==            
                //txtDecryptedValue.Text = SSTCryptographer.Decrypt(txtEncryptedValue.Text, "SampleKey");
                //txtEncryptedValue.Text = SSTCryptographer.Encrypt(txtSerialNo.Text, "SampleKey");


                clsIniFiles ini = new clsIniFiles(Application.StartupPath + "\\AccountLog.ini");
                if (txtLoginID.Text != "techmetro")
                {
                    string UserName = SSTCryptographer.Decrypt(ini.IniReadValue("Client AccountDetails", "User Id"), "SampleKey");
                    string Password = SSTCryptographer.Decrypt(ini.IniReadValue("Client AccountDetails", "Password"), "SampleKey");
                    if(txtPwd.Text== Password)
                    {
                        this.Hide();
                        Program.objclsComm.objFrmMain = new frmMain();
                        Program.objclsComm.objFrmMain.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Please Enter Currect User Name Or Password");
                    }
                }
                else if (txtLoginID.Text == "techmetro")
                {                  
                   // string UserName = SSTCryptographer.Decrypt(ini.IniReadValue("Techmetro AccountDetails", "User Id"), "SampleKey");
                    fnDynamicPassword();
                    if (txtPwd.Text == strDate)
                    {
                        this.Hide();
                        Program.objclsComm.objFrmMain = new frmMain();
                        Program.objclsComm.objFrmMain.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Please Enter Currect User Name Or Password");
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error("btnLogin_Click()" + ex.Message);
            }
            Logger.Info("Exiting into btnLogin_Click()");
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            try
            {
                Logger.Info("Entering into btnExit_Click");
                this.Close();

            }
            catch (Exception ex)
            {
                Logger.Error("btnExit_Click()" + ex.Message);
            }
            Logger.Info("Exiting into btnExit_Click()");
        }
        public void fnDynamicPassword()
        {
            CultureInfo currentCulture = Thread.CurrentThread.CurrentCulture;
            strOriginalCulture = currentCulture.ToString();
            if (currentCulture.ToString() != "en-US")
            {
                System.Threading.Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("en-US");
                blnCulture = true;
            }
            iWeekNo = (Convert.ToInt32(System.DateTime.Today.DayOfYear) / 7) + 1;
            iMM = Convert.ToInt32(System.DateTime.Today.Month);
            iDD = Convert.ToInt32(System.DateTime.Today.Day);
            iYYYY = Convert.ToInt32(System.DateTime.Today.Year);
            iCCCC = 9999 - iYYYY;
            switch (iWeekNo % 4)
            {
                case 0:
                    strDate = (iWeekNo * (iWeekNo + 2)) + ":" + (iWeekNo * (iWeekNo + 3)) + ":" + iCCCC * iWeekNo * iWeekNo + ":" + (iWeekNo + iWeekNo + iWeekNo + iCCCC);
                    break;
                case 1:
                    strDate = (iWeekNo * (iWeekNo + 3)) + ":" + (iWeekNo * (iWeekNo + 2)) + ":" + iCCCC * iWeekNo * iWeekNo + ":" + (iWeekNo + iWeekNo + iWeekNo + iCCCC);
                    break;
                case 2:
                    strDate = iCCCC * iWeekNo * iWeekNo + ":" + (iWeekNo * (iWeekNo + 2)) + ":" + (iWeekNo * (iWeekNo + 3)) + ":" + (iWeekNo + iWeekNo + iWeekNo + iCCCC);
                    break;
                case 3:
                    strDate = (iWeekNo + iWeekNo + iCCCC) + ":" + (iWeekNo * (iWeekNo + 2)) + ":" + (iWeekNo * (iWeekNo + 3)) + ":" + iCCCC * iWeekNo * iWeekNo;
                    break;
            }
            // strDate = (iMM * (iDayNo + 2)) + ":" + (iDD * (iDayNo + 3)) + ":" + iCCCC*iDayNo*iDayNo + ":" + (iDayNo + iMM + iDD + iCCCC);
            //txtPassword.Text = strDate;
            if (blnCulture)
            {
                System.Threading.Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo(strOriginalCulture);
                blnCulture = false;
            }
        }

        private void txtPwd_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                btnLogin.PerformClick();
            }
        }
    }
}
