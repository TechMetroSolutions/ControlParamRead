﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using System.Collections.Generic;

namespace PLCCommunication
{
    public partial class FrmRegistration : Form
    {
        TMLicenseValidation.clsLisenceValidity objLicense;
        string strSrNo = string.Empty;
        TMLicenseEncryption.ClsEncryption objEnc = new TMLicenseEncryption.ClsEncryption();
        public FrmRegistration()
        {
            InitializeComponent();
        }
        public FrmRegistration(string strSerialNo)
        {
            InitializeComponent();
            strSrNo = strSerialNo;
        }

        private void FrmRegistration_Load(object sender, EventArgs e)
        {
            try
            {
                Logger.Info("Entering into FrmRegistration_Load");
                objLicense = new TMLicenseValidation.clsLisenceValidity();
                txtProductKey.Text = objLicense.GetMACAddress();
                Logger.Info("Exit from FrmRegistration_Load");
            }
            catch (ArgumentException ex)
            {
                this.TopMost = true;
                Logger.Error(ex.Message);
            }
            catch (Exception ex)
            {
                this.TopMost = true;
                Logger.Error(ex.Message);
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            //try
            //{
            //    Logger.Info("Entering into btnRegister_Click");
            //    if (string.IsNullOrEmpty(txtRegistrationKey.Text))
            //    {
            //        this.TopMost = true;
            //    }
            //    else
            //    {
            //        if (objLicense.fnCheckFileExist() == true)
            //        {
            //            if (objLicense.fnCheckKeyRepeatation(objEnc.FnDecryptLicenseKey(txtRegistrationKey.Text)) == true)
            //            {
            //                objLicense.fnFirstSerialization(objEnc.FnDecryptLicenseKey(txtRegistrationKey.Text));
            //            }
            //            else
            //            {
            //                this.TopMost = true;
            //            }
            //        }
            //        else
            //        {
            //            objLicense.fnFirstSerialization((txtRegistrationKey.Text) + (Program.objCommonClass.fnGetSrNoFromFile()));
            //        }

            //        if (Program.objLisenceValidity.fnGetLicenseType() == "2")
            //        {
            //            List<string> strlstLicDetails = Program.objCommonClass.fnGetDataFromDongal();
            //            bool blnLicAvailable = false;
            //            for (int i = 0; i < 3; i++)
            //            {
            //                if (strlstLicDetails[i] == "")
            //                {
            //                    blnLicAvailable = true;

            //                    string strLicenseNo = objEnc.FnEncryptLiceenseKey(0, fnPadZero(System.DateTime.Now.DayOfYear.ToString(), 3) + Program.objCommonClass.strSoftwareID + objLicense.GetMACAddress());
            //                    Program.objCommonClass.fnWriteLicense((i + 1), strLicenseNo);
            //                    break;
            //                }
            //            }
            //            if (!blnLicAvailable)
            //            {
            //                MessageBox.Show("License limit is over. Please contact your Administrator to get new license dongal.");
            //            }
            //        }
            //    }// else 1
            //    Logger.Info("Exit from btnRegister_Click");
            //}

            //catch (InvalidEnumArgumentException ex)
            //{
            //    //                MessageBox.Show(ex.Message, Properties.Resources.Error,
            //    //MessageBoxButtons.OK, MessageBoxIcon.Error ,
            //    //MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
            //    this.TopMost = true;
            //    //Logger.Error(ex.Message + ex.Source);
            //}
            //catch (ArgumentException ex)
            //{
            //    //                MessageBox.Show(ex.Message, Properties.Resources.Error,
            //    //MessageBoxButtons.OK, MessageBoxIcon.Error ,
            //    //MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
            //    this.TopMost = true;
            //    // Logger.Error(ex.Message + ex.Source);
            //}
            //catch (Exception ex)
            //{
            //    //MessageBox.Show(ex.Message, Properties.Resources.Error,
            //    //         MessageBoxButtons.OK, MessageBoxIcon.Error ,
            //    //         MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
            //    this.TopMost = true;
            //    //MessageBox.Show(ex.Message);
            //    // Logger.Error(ex.Message);
            //}
            //// Logger.Info("Exiting from btnRegister_Click()");

            //this.Close();
        }// btn register

        private void btnExit_Click(object sender, EventArgs e)
        {
            Logger.Info("Entering into btnExit_Click");
            this.Close();
            Logger.Info("Exit from btnExit_Click");

        }

        private string fnPadZero(string Str, int Counter)
        {
            try
            {
                Logger.Info("Entering into fnPadZero");
                while (Counter > Str.Length)
                {
                    Str = "0" + Str;
                }
                Logger.Info("Exit from fnPadZero");
            }
            catch (Exception ex)
            {
                Logger.Error(ex.Message);
            }
            return Str;
        }
    }

}
